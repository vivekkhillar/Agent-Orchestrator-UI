import pg from 'pg';
import fs from 'fs';
import path from 'path';

const { Pool } = pg;

// Setup File Logger Directory
const LOGS_DIR = path.join(process.cwd(), 'logs');
if (!fs.existsSync(LOGS_DIR)) {
  try {
    fs.mkdirSync(LOGS_DIR, { recursive: true });
  } catch (e) {
    console.error('Could not create logs directory:', e);
  }
}
const AUDIT_LOG_FILE = path.join(LOGS_DIR, 'banking_audit.log');
const LLM_LOG_FILE = path.join(LOGS_DIR, 'llm_invocations.log');

export interface LLMEvaluationEntry {
  timestamp: string;
  requestId: string;
  caller: string;
  functionName: string;
  model: string;
  provider: 'gemini' | 'ollama' | 'fallback_engine';
  prompt: string;
  systemInstruction?: string;
  response: string;
  latencyMs: number;
  tokenCountEstimate?: number;
  intentIdentified?: string;
  evaluationStatus: 'SUCCESS' | 'FALLBACK' | 'ERROR';
  evaluationMetrics?: {
    accuracyScore?: number;
    currencyAdherence?: boolean; // Checks if output correctly used ₹ (INR)
    schemaValid?: boolean;
    reasoningQuality?: string;
  };
}

export interface StepLogEntry {
  timestamp?: string;
  stepNumber?: number | string;
  stepName?: string;
  source: string;
  level: 'INFO' | 'STEP_START' | 'STEP_PROGRESS' | 'STEP_SUCCESS' | 'STEP_FAILED' | 'STEP_VALIDATION' | 'ORCHESTRATION' | 'LLM_INVOCATION' | 'SQL_QUERY' | 'AGENT_ACTION' | 'FUNCTION_CALL' | 'ERROR';
  status?: 'STARTED' | 'IN_PROGRESS' | 'SUCCESS' | 'FAILED' | 'VALIDATED' | 'FALLBACK';
  message: string;
  details?: {
    input?: any;
    output?: any;
    validationCriteria?: string;
    validationPassed?: boolean;
    errorReason?: string;
    diagnostics?: string;
    executionTimeMs?: number;
    [key: string]: any;
  };
  data?: any;
}

export function writeToFileLog(entry: StepLogEntry | {
  timestamp?: string;
  source: string;
  level: 'INFO' | 'ORCHESTRATION' | 'LLM_INVOCATION' | 'SQL_QUERY' | 'AGENT_ACTION' | 'FUNCTION_CALL' | 'ERROR' | 'STEP_START' | 'STEP_PROGRESS' | 'STEP_SUCCESS' | 'STEP_FAILED' | 'STEP_VALIDATION';
  message: string;
  data?: any;
  stepNumber?: number | string;
  stepName?: string;
  status?: 'STARTED' | 'IN_PROGRESS' | 'SUCCESS' | 'FAILED' | 'VALIDATED' | 'FALLBACK';
  details?: any;
}) {
  const ts = entry.timestamp || new Date().toISOString();
  
  const stepPrefix = entry.stepNumber !== undefined 
    ? `[STEP ${entry.stepNumber}${entry.stepName ? `: ${entry.stepName}` : ''}] `
    : '';

  const statusSuffix = entry.status ? ` [STATUS: ${entry.status}]` : '';

  let detailString = '';
  if (entry.details) {
    detailString += ` | Details: ${JSON.stringify(entry.details)}`;
  }
  if (entry.data) {
    detailString += ` | Payload: ${JSON.stringify(entry.data)}`;
  }

  // Format log with distinct visual clarity for step validation
  const separator = entry.level === 'STEP_START' 
    ? `\n>>> -------------------- [STEP ${entry.stepNumber || 'INIT'}: ${entry.stepName || entry.message}] --------------------\n`
    : (entry.level === 'STEP_FAILED' ? `\n--- [STEP ${entry.stepNumber || 'FALLBACK'}: EXECUTION / VALIDATION FALLBACK] ---\n` : '');

  const logLine = `${separator}[${ts}] [${entry.level}] [${entry.source}] ${stepPrefix}${entry.message}${statusSuffix}${detailString}\n`;

  try {
    fs.appendFileSync(AUDIT_LOG_FILE, logLine, 'utf8');
    // Also emit to console with high clarity for runtime inspection
    if (entry.level === 'ERROR') {
      console.error(`[LOGGER ERROR] ${logLine.trim()}`);
    } else if (entry.level === 'STEP_FAILED') {
      console.warn(`[LOGGER STEP FALLBACK] ${logLine.trim()}`);
    } else if (entry.level === 'STEP_START' || entry.level === 'STEP_SUCCESS' || entry.level === 'STEP_VALIDATION') {
      console.log(`[LOGGER STEP] ${logLine.trim()}`);
    }
  } catch (err) {
    console.error('Failed to append to audit log file:', err);
  }
}

export function writeLLMEvaluationLog(entry: LLMEvaluationEntry) {
  const ts = entry.timestamp || new Date().toISOString();
  const logEntry = JSON.stringify({
    ...entry,
    timestamp: ts
  }) + '\n';

  try {
    fs.appendFileSync(LLM_LOG_FILE, logEntry, 'utf8');
  } catch (err) {
    console.error('Failed to append to LLM log file:', err);
  }

  // Also write high-level entry to audit log for unified tracing
  writeToFileLog({
    timestamp: ts,
    source: entry.caller || entry.functionName,
    level: 'LLM_INVOCATION',
    message: `[LLM Evaluation] ${entry.functionName} executed via ${entry.model} (${entry.latencyMs}ms) - Status: ${entry.evaluationStatus}`,
    data: {
      provider: entry.provider,
      intent: entry.intentIdentified,
      currencyAdherence: entry.evaluationMetrics?.currencyAdherence
    }
  });
}

export function readAuditLogFile(limitLines: number = 200): string {
  try {
    if (!fs.existsSync(AUDIT_LOG_FILE)) {
      return `[${new Date().toISOString()}] [INFO] [SYSTEM] Audit log initialized. Logs are stored in logs/banking_audit.log\n`;
    }
    const content = fs.readFileSync(AUDIT_LOG_FILE, 'utf8');
    const lines = content.trim().split('\n');
    return lines.slice(-limitLines).join('\n');
  } catch (err) {
    return `[ERROR] Failed to read log file: ${String(err)}`;
  }
}

export function readLLMEvaluationLogFile(limitEntries: number = 50): any[] {
  try {
    if (!fs.existsSync(LLM_LOG_FILE)) {
      return [];
    }
    const content = fs.readFileSync(LLM_LOG_FILE, 'utf8');
    const lines = content.trim().split('\n').filter(Boolean);
    const entries = lines.slice(-limitEntries).map(line => {
      try {
        return JSON.parse(line);
      } catch {
        return { raw: line };
      }
    });
    return entries.reverse(); // Newest first
  } catch (err) {
    return [{ error: `Failed to read LLM evaluations: ${String(err)}` }];
  }
}

// PostgreSQL Connection Pool Setup
const databaseUrl = process.env.DATABASE_URL || 
  (process.env.POSTGRES_HOST ? `postgresql://${process.env.POSTGRES_USER || 'postgres'}:${process.env.POSTGRES_PASSWORD || 'postgrespassword'}@${process.env.POSTGRES_HOST}:${process.env.POSTGRES_PORT || 5432}/${process.env.POSTGRES_DB || 'banking_db'}` : null);

let pgPool: pg.Pool | null = null;
let isPostgresConnected = false;

if (databaseUrl) {
  try {
    pgPool = new Pool({
      connectionString: databaseUrl,
      connectionTimeoutMillis: 3000,
    });
    pgPool.query('SELECT NOW()', (err, res) => {
      if (err) {
        console.log('[PostgreSQL] Running in in-memory PostgreSQL engine mode (PostgreSQL container ready for connection).');
        writeToFileLog({
          source: 'PostgreSQL_Pool',
          level: 'INFO',
          message: 'PostgreSQL container connection standby. In-memory PostgreSQL store active.',
          data: { error: err.message }
        });
      } else {
        isPostgresConnected = true;
        console.log('[PostgreSQL] Connected to active PostgreSQL database at', databaseUrl);
        writeToFileLog({
          source: 'PostgreSQL_Pool',
          level: 'INFO',
          message: 'Successfully connected to live PostgreSQL database.',
          data: { serverTime: res.rows[0].now }
        });
      }
    });
  } catch (err: any) {
    console.error('[PostgreSQL] Initialization notice:', err.message);
  }
}

// Default Seed Accounts Database (INR Currency ₹)
export interface AccountRecord {
  account_id: string;
  account_holder: string;
  account_type: string;
  currency: string;
  currency_symbol: string;
  checking_balance: number;
  savings_balance: number;
  available_balance: number;
  total_ledger_balance: number;
  pending_holds: number;
  credit_limit: number;
  status: string;
  ifsc_code: string;
  branch_name: string;
  last_reconciled: string;
}

export interface TransactionRecord {
  transaction_id: string;
  account_id: string;
  date: string;
  description: string;
  category: string;
  type: 'CREDIT' | 'DEBIT';
  amount: number;
  balance_after: number;
  currency: string;
  currency_symbol: string;
  reference_no: string;
}

// In-Memory PostgreSQL Store (synchronized with init.sql schema)
const inMemoryAccounts: Map<string, AccountRecord> = new Map([
  [
    'ACC-94820',
    {
      account_id: 'ACC-94820',
      account_holder: 'First Digital Treasury & Operating Corp',
      account_type: 'CORPORATE_TREASURY',
      currency: 'INR',
      currency_symbol: '₹',
      checking_balance: 98450.50,
      savings_balance: 44400.00,
      available_balance: 139430.50,
      total_ledger_balance: 142850.50,
      pending_holds: 3420.00,
      credit_limit: 500000.00,
      status: 'ACTIVE_VERIFIED',
      ifsc_code: 'FDTR0009482',
      branch_name: 'Mumbai Corporate Treasury Branch',
      last_reconciled: new Date().toISOString()
    }
  ],
  [
    'ACC-10029',
    {
      account_id: 'ACC-10029',
      account_holder: 'Global Multi-Currency Operating Account',
      account_type: 'GLOBAL_COMMERCIAL',
      currency: 'INR',
      currency_symbol: '₹',
      checking_balance: 245000.00,
      savings_balance: 180000.00,
      available_balance: 412500.00,
      total_ledger_balance: 425000.00,
      pending_holds: 12500.00,
      credit_limit: 1000000.00,
      status: 'ACTIVE_VERIFIED',
      ifsc_code: 'FDTR0001002',
      branch_name: 'Bengaluru FinTech Center',
      last_reconciled: new Date().toISOString()
    }
  ],
  [
    'ACC-55210',
    {
      account_id: 'ACC-55210',
      account_holder: 'Vivek Khillar - Premium Personal Reserve',
      account_type: 'PRIVATE_WEALTH',
      currency: 'INR',
      currency_symbol: '₹',
      checking_balance: 542300.00,
      savings_balance: 850000.00,
      available_balance: 1387300.00,
      total_ledger_balance: 1392300.00,
      pending_holds: 5000.00,
      credit_limit: 2000000.00,
      status: 'ACTIVE_VERIFIED',
      ifsc_code: 'FDTR0005521',
      branch_name: 'New Delhi Executive Lounge',
      last_reconciled: new Date().toISOString()
    }
  ]
]);

const inMemoryTransactions: TransactionRecord[] = [
  {
    transaction_id: 'TXN_1091',
    account_id: 'ACC-94820',
    date: new Date(Date.now() - 86400000 * 1).toISOString().split('T')[0],
    description: 'RAZORPAY MERCHANT SETTLEMENT INFLOW',
    category: 'Revenue / Merchant',
    type: 'CREDIT',
    amount: 42500.00,
    balance_after: 139430.50,
    currency: 'INR',
    currency_symbol: '₹',
    reference_no: 'UPI-REF-908123841'
  },
  {
    transaction_id: 'TXN_1090',
    account_id: 'ACC-94820',
    date: new Date(Date.now() - 86400000 * 3).toISOString().split('T')[0],
    description: 'CLOUD SERVER INFRASTRUCTURE & AWS SERVICES',
    category: 'Cloud Infrastructure',
    type: 'DEBIT',
    amount: -4820.00,
    balance_after: 96930.50,
    currency: 'INR',
    currency_symbol: '₹',
    reference_no: 'NEFT-AWS-0091823'
  },
  {
    transaction_id: 'TXN_1089',
    account_id: 'ACC-94820',
    date: new Date(Date.now() - 86400000 * 5).toISOString().split('T')[0],
    description: 'MONTHLY PAYROLL DIRECT DEPOSIT - TECH STAFF',
    category: 'Payroll & Staff',
    type: 'DEBIT',
    amount: -12400.00,
    balance_after: 101750.50,
    currency: 'INR',
    currency_symbol: '₹',
    reference_no: 'IMPS-PAY-4410294'
  },
  {
    transaction_id: 'TXN_1088',
    account_id: 'ACC-94820',
    date: new Date(Date.now() - 86400000 * 9).toISOString().split('T')[0],
    description: 'ENTERPRISE CLIENT CONTRACT ADVANCE (WIRE)',
    category: 'Revenue / Contracts',
    type: 'CREDIT',
    amount: 21700.00,
    balance_after: 114150.50,
    currency: 'INR',
    currency_symbol: '₹',
    reference_no: 'RTGS-CLIENT-88192'
  },
  {
    transaction_id: 'TXN_1087',
    account_id: 'ACC-94820',
    date: new Date(Date.now() - 86400000 * 14).toISOString().split('T')[0],
    description: 'DEVELOPER TOOLS & AI API SUBSCRIPTION',
    category: 'Software Subscriptions',
    type: 'DEBIT',
    amount: -1200.00,
    balance_after: 92450.50,
    currency: 'INR',
    currency_symbol: '₹',
    reference_no: 'CARD-SUB-1120938'
  }
];

// SQL Query Execution Functions
export async function getAccountFromPostgres(accountId: string): Promise<AccountRecord> {
  const sqlQuery = `SELECT * FROM accounts WHERE account_id = $1 LIMIT 1;`;
  
  writeToFileLog({
    source: 'PostgreSQL_Query',
    level: 'SQL_QUERY',
    message: `Executing: ${sqlQuery}`,
    data: { params: [accountId] }
  });

  if (isPostgresConnected && pgPool) {
    try {
      const res = await pgPool.query(sqlQuery, [accountId]);
      if (res.rows.length > 0) {
        const row = res.rows[0];
        const record: AccountRecord = {
          account_id: row.account_id,
          account_holder: row.account_holder,
          account_type: row.account_type,
          currency: row.currency || 'INR',
          currency_symbol: row.currency_symbol || '₹',
          checking_balance: parseFloat(row.checking_balance),
          savings_balance: parseFloat(row.savings_balance),
          available_balance: parseFloat(row.available_balance || (row.checking_balance + row.savings_balance - row.pending_holds)),
          total_ledger_balance: parseFloat(row.total_ledger_balance || (row.checking_balance + row.savings_balance)),
          pending_holds: parseFloat(row.pending_holds),
          credit_limit: parseFloat(row.credit_limit),
          status: row.status,
          ifsc_code: row.ifsc_code,
          branch_name: row.branch_name,
          last_reconciled: row.last_reconciled
        };
        return record;
      }
    } catch (err: any) {
      writeToFileLog({
        source: 'PostgreSQL_Query',
        level: 'ERROR',
        message: `PostgreSQL query error: ${err.message}. Falling back to PostgreSQL memory instance.`,
      });
    }
  }

  // In-Memory PostgreSQL Store fallback
  let record = inMemoryAccounts.get(accountId);
  if (!record) {
    // Generate valid INR Account for unknown ID dynamically
    record = {
      account_id: accountId,
      account_holder: `Treasury Account Holder (${accountId})`,
      account_type: 'PRIMARY_TREASURY',
      currency: 'INR',
      currency_symbol: '₹',
      checking_balance: 75000.00,
      savings_balance: 32000.00,
      available_balance: 105500.00,
      total_ledger_balance: 107000.00,
      pending_holds: 1500.00,
      credit_limit: 500000.00,
      status: 'ACTIVE_VERIFIED',
      ifsc_code: 'FDTR0009482',
      branch_name: 'Mumbai Corporate Treasury Branch',
      last_reconciled: new Date().toISOString()
    };
    inMemoryAccounts.set(accountId, record);
  }

  return record;
}

export async function getTransactionsFromPostgres(accountId: string, limitDays: number = 30): Promise<TransactionRecord[]> {
  const sqlQuery = `SELECT * FROM transactions WHERE account_id = $1 ORDER BY date DESC, id DESC;`;

  writeToFileLog({
    source: 'PostgreSQL_Query',
    level: 'SQL_QUERY',
    message: `Executing: ${sqlQuery}`,
    data: { params: [accountId, `${limitDays} days`] }
  });

  if (isPostgresConnected && pgPool) {
    try {
      const res = await pgPool.query(sqlQuery, [accountId]);
      if (res.rows.length > 0) {
        return res.rows.map((row: any) => ({
          transaction_id: row.transaction_id,
          account_id: row.account_id,
          date: row.date ? new Date(row.date).toISOString().split('T')[0] : '',
          description: row.description,
          category: row.category,
          type: row.type,
          amount: parseFloat(row.amount),
          balance_after: parseFloat(row.balance_after),
          currency: row.currency || 'INR',
          currency_symbol: row.currency_symbol || '₹',
          reference_no: row.reference_no
        }));
      }
    } catch (err: any) {
      writeToFileLog({
        source: 'PostgreSQL_Query',
        level: 'ERROR',
        message: `PostgreSQL query error: ${err.message}. Falling back to in-memory transactions.`,
      });
    }
  }

  return inMemoryTransactions.filter(t => t.account_id === accountId || accountId === 'ACC-94820');
}

export async function logIntentToPostgres(data: {
  query_text: string;
  classified_intent: string;
  confidence: number;
  llm_reasoning: string;
  assigned_agent: string;
  llm_model: string;
}) {
  const sqlQuery = `INSERT INTO intent_classifications (query_text, classified_intent, confidence, llm_reasoning, assigned_agent, llm_model) VALUES ($1, $2, $3, $4, $5, $6);`;

  writeToFileLog({
    source: 'Intent_Classification',
    level: 'LLM_INVOCATION',
    message: `Classified Query: "${data.query_text}" -> [${data.classified_intent}] via ${data.llm_model}`,
    data: {
      confidence: data.confidence,
      reasoning: data.llm_reasoning,
      assignedAgent: data.assigned_agent
    }
  });

  if (isPostgresConnected && pgPool) {
    try {
      await pgPool.query(sqlQuery, [
        data.query_text,
        data.classified_intent,
        data.confidence,
        data.llm_reasoning,
        data.assigned_agent,
        data.llm_model
      ]);
    } catch (e) {
      // Ignored
    }
  }
}

export async function logAuditToPostgres(data: {
  log_id: string;
  agent_id: string;
  agent_name: string;
  agent_role: string;
  log_type: string;
  message: string;
  metadata?: any;
}) {
  const sqlQuery = `INSERT INTO audit_logs (log_id, agent_id, agent_name, agent_role, log_type, message, metadata) VALUES ($1, $2, $3, $4, $5, $6, $7);`;

  writeToFileLog({
    source: `${data.agent_name}_[${data.agent_role}]`,
    level: 'AGENT_ACTION',
    message: data.message,
    data: data.metadata
  });

  if (isPostgresConnected && pgPool) {
    try {
      await pgPool.query(sqlQuery, [
        data.log_id,
        data.agent_id,
        data.agent_name,
        data.agent_role,
        data.log_type,
        data.message,
        JSON.stringify(data.metadata || {})
      ]);
    } catch (e) {
      // Ignored
    }
  }
}
