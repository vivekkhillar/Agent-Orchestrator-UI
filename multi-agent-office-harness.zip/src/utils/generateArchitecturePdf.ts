import { jsPDF } from 'jspdf';

export function generateArchitecturePdf(): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;
  let y = margin;

  const addNewPageIfNeeded = (requiredSpace: number = 20) => {
    if (y + requiredSpace > pageHeight - margin) {
      doc.addPage();
      y = margin;
      drawHeaderFooter();
    }
  };

  const drawHeaderFooter = () => {
    const totalPages = (doc as any).internal.getNumberOfPages();
    const currentPage = (doc as any).internal.getCurrentPageInfo().pageNumber;

    // Header bar
    doc.setFillColor(24, 40, 28);
    doc.rect(0, 0, pageWidth, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(110, 231, 183);
    doc.text('FIRST DIGITAL TREASURY • MULTI-AGENT BANKING HARNESS • ARCHITECTURE SPECIFICATION', margin, 5.5);

    // Footer bar
    doc.setFillColor(245, 247, 245);
    doc.rect(0, pageHeight - 8, pageWidth, 8, 'F');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text('CONFIDENTIAL • SYSTEM INTEGRATION & SEQUENCE DOCUMENT', margin, pageHeight - 3);
    doc.text(`Page ${currentPage}`, pageWidth - margin - 10, pageHeight - 3);
  };

  drawHeaderFooter();
  y = 16;

  // Title Box
  doc.setFillColor(15, 23, 42);
  doc.roundedRect(margin, y, pageWidth - (margin * 2), 26, 2, 2, 'F');
  
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(255, 255, 255);
  doc.text('Multi-Agent Banking Architecture & Integration Document', margin + 6, y + 9);
  
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(148, 163, 184);
  doc.text('End-to-End Query Lifecycle, Function Call Hierarchy, Data Flow & Step Validation Engine', margin + 6, y + 16);
  
  doc.setFontSize(7.5);
  doc.setTextColor(52, 211, 153);
  doc.text('Author: Lead System Architect | Primary LLM: Gemini 3.7 Flash | Fallback: Ollama phi3:mini | Currency: INR (₹)', margin + 6, y + 22);

  y += 32;

  // Section 1: Executive Architecture Overview
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('1. EXECUTIVE ARCHITECTURE OVERVIEW', margin, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  const overviewText = 
    'The Multi-Agent Banking Harness is an enterprise-grade agentic pipeline executing under a strict hierarchy governed by Boss EVA (Cabin 0x1) and dedicated sub-agents: Specialist VK (Desk 1: Balance Inquiry) and Specialist RO (Desk 2: Account Statements). All database operations query PostgreSQL in Indian Rupees (INR / ₹) with zero database access for greetings. The LLM pipeline enforces a strict 2-tier fallback: Google Gemini 3.7 Flash as primary, failing over to local Ollama (phi3:mini). Every step is audited with raw request/response logging and written to persistent logs for real-time validation.';
  const splitOverview = doc.splitTextToSize(overviewText, pageWidth - (margin * 2));
  doc.text(splitOverview, margin, y);
  y += splitOverview.length * 4 + 4;

  // Section 2: End-to-End Function Sequence Map
  addNewPageIfNeeded(40);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('2. FUNCTION CALL SEQUENCE & DATA TRANSFORMATION FLOW', margin, y);
  y += 5;

  const steps = [
    {
      num: 'STEP 1',
      title: 'Customer Query Ingestion & Dynamic Account Parsing',
      fn: 'extractAccountIdFromPrompt(prompt) / extractAccountIdFromText()',
      api: 'Client UI -> Frontend Dispatcher (App.tsx: dispatchTask)',
      input: 'Customer natural language prompt (e.g., "What is balance for ACC-94820?")',
      action: 'Extracts ACC-XXXXX pattern or contextual account phrases. If missing, NO account ID is passed or assumed.',
      output: '{ prompt: string, accountId: string | null }'
    },
    {
      num: 'STEP 2',
      title: 'Boss EVA Dynamic Intent Classification & Subtask Breakdown',
      fn: 'handleOrchestration() -> invokeLLMTwoTier()',
      api: 'POST /api/agent/orchestrate & /api/agent/orchestrator/dispatch',
      input: '{ prompt, accountId?, customInstructions?, model }',
      action: 'Boss EVA invokes LLM in Cabin [0x1] using INTENT_CLASSIFICATION_SYSTEM_PROMPT to classify intent (greetings, balance_inquiry, account_statement) and generate structured subtasks.',
      output: '{ intent, intentConfidence, reasoning, subtasks: [...], rawRequest, rawResponse }'
    },
    {
      num: 'STEP 3',
      title: 'Routing & Office Physical Dispatch',
      fn: 'dispatchTask() state machine / LangGraph routing',
      api: 'Frontend Animation State & Agent Movement (OfficeCanvas)',
      input: '{ subtasks, assignedAgentId }',
      action: 'If greetings: Zero subtasks created; EVA responds directly from Cabin 0x1. If banking: Subtasks dispatched to Specialist VK (Balance) or RO (Statement). Sub-agent walks to Boss Cabin [0x1] to receive assignment briefing and API schema.',
      output: 'Visual State: activeStage, agent state: walking_to_boss -> in_boss_cabin, audio SFX'
    },
    {
      num: 'STEP 4',
      title: 'Physical Movement to PostgreSQL Room & Live SQL Query Execution',
      fn: 'handleAgentExecute() -> getPathToPostgres() -> getAccountFromPostgres()',
      api: 'POST /api/agent/execute_subtask & /api/fastapi/agent/execute',
      input: '{ subtask, agent, prompt, accountId? }',
      action: 'Specialist physically navigates from Cabin/Desk to PostgreSQL Server Room [0x3, Port 5432], queries live accounts ledger in ₹ (INR), executes SQL at the DB console, returns to desk to code the FastAPI microservice, then submits verified artifact to Boss EVA.',
      output: '{ success: true, speechSummary, thoughtLog, code: { filename, content }, executionOutput }'
    },
    {
      num: 'STEP 5',
      title: 'Boss EVA Final Customer Response Synthesis',
      fn: 'app.post("/api/fastapi/eva/synthesize") -> invokeLLMTwoTier()',
      api: 'POST /api/fastapi/eva/synthesize',
      input: '{ intent, subtaskResults, prompt, accountId? }',
      action: 'Boss EVA reviews specialist findings or direct greetings context and synthesizes final customer greeting and verified monetary balance in ₹ INR without data hallucination.',
      output: '{ success: true, customer_response, usedEngine, fallbackTriggered, rawRequest, rawResponse }'
    },
    {
      num: 'STEP 6',
      title: 'Step Logger & Comprehensive Audit Validation',
      fn: 'writeToFileLog() & logAuditToPostgres()',
      api: 'POST /api/logs/step & File System Sync',
      input: '{ source, level, stepNumber, stepName, status, message, details }',
      action: 'Appends structured validation entry to server logs and database audit table. If any step fails, error reason and step details are logged for immediate troubleshooting.',
      output: 'Persistent log entry with validation status (STARTED, IN_PROGRESS, COMPLETED, FAILED, VALIDATED)'
    }
  ];

  steps.forEach((step) => {
    addNewPageIfNeeded(32);
    // Card Box
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(margin, y, pageWidth - (margin * 2), 28, 1.5, 1.5, 'FD');

    // Step Header Pill
    doc.setFillColor(16, 185, 129);
    doc.roundedRect(margin + 2, y + 2.5, 16, 4.5, 1, 1, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(255, 255, 255);
    doc.text(step.num, margin + 4, y + 5.8);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(15, 23, 42);
    doc.text(step.title, margin + 20, y + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.8);
    doc.setTextColor(71, 85, 105);

    doc.setFont('helvetica', 'bold');
    doc.text('Function: ', margin + 3, y + 11);
    doc.setFont('helvetica', 'normal');
    doc.text(step.fn, margin + 18, y + 11);

    doc.setFont('helvetica', 'bold');
    doc.text('API Route: ', margin + 3, y + 15);
    doc.setFont('helvetica', 'normal');
    doc.text(step.api, margin + 18, y + 15);

    doc.setFont('helvetica', 'bold');
    doc.text('Actions: ', margin + 3, y + 19);
    doc.setFont('helvetica', 'normal');
    const splitAction = doc.splitTextToSize(step.action, pageWidth - margin * 2 - 20);
    doc.text(splitAction, margin + 18, y + 19);

    doc.setFont('helvetica', 'bold');
    doc.text('Outcome: ', margin + 3, y + 25);
    doc.setFont('helvetica', 'normal');
    doc.text(step.output, margin + 18, y + 25);

    y += 31;
  });

  // Section 3: Architecture Sequence Diagram (ASCII Art)
  addNewPageIfNeeded(65);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('3. INTEGRATION ARCHITECTURE FLOW DIAGRAM', margin, y);
  y += 5;

  const diagram = [
    '   +-------------------------------------------------------------------------+',
    '   |                           CUSTOMER CLIENT (UI)                          |',
    '   +-------------------------------------------------------------------------+',
    '                                        |',
    '              1. User Query Prompt (with dynamic Account ID extraction)',
    '                                        v',
    '   +-------------------------------------------------------------------------+',
    '   |  BOSS EVA [0x1] - Intent Classification (POST /api/agent/orchestrate)    |',
    '   |  LLM Pipeline: Gemini 3.7 Flash  -->  Fallback: Ollama (phi3:mini)     |',
    '   +-------------------------------------------------------------------------+',
    '                   /                        |                       \\',
    '     [Intent: Greetings]      [Intent: Balance Inquiry]   [Intent: Statement]',
    '              |                             |                        |',
    '              v                             v                        v',
    '    +-------------------+         +-------------------+    +-----------------+',
    '    | ZERO DB ACCESS    |         | SPECIALIST VK     |    | SPECIALIST RO   |',
    '    | Cabin [0x1] Direct|         | Desk 1 (Balance)  |    | Desk 2(Stmt)    |',
    '    +-------------------+         +-------------------+    +-----------------+',
    '              |                             |                        |',
    '              |                   SQL: SELECT accounts     SQL: SELECT txns  |',
    '              |                             |                        |',
    '              |                   Reconcile INR (₹)        Reconcile INR (₹) |',
    '              \\_____________________________|________________________/',
    '                                        |',
    '                                        v',
    '   +-------------------------------------------------------------------------+',
    '   | BOSS EVA [0x1] - Final Synthesis (POST /api/fastapi/eva/synthesize)    |',
    '   | Format Response in INR (₹) + Raw Request/Response Audit Ingestion      |',
    '   +-------------------------------------------------------------------------+',
    '                                        |',
    '                     6. Verified Customer Output Returned',
    '                                        v',
    '   +-------------------------------------------------------------------------+',
    '   |   STEP LOGGER (writeToFileLog) + POSTGRES AUDIT (logAuditToPostgres)    |',
    '   +-------------------------------------------------------------------------+'
  ];

  doc.setFillColor(15, 23, 42);
  doc.rect(margin, y, pageWidth - (margin * 2), 52, 'F');
  doc.setFont('courier', 'bold');
  doc.setFontSize(5.8);
  doc.setTextColor(52, 211, 153);
  let diagY = y + 4;
  diagram.forEach(line => {
    doc.text(line, margin + 2, diagY);
    diagY += 1.7;
  });

  y += 56;

  // Section 4: Data Flow Matrix & API Specifications Table
  addNewPageIfNeeded(50);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('4. API INTEGRATION MATRIX & CONTRACTS', margin, y);
  y += 5;

  const apiTable = [
    {
      route: '/api/agent/orchestrate',
      method: 'POST',
      desc: 'Dynamic intent classification and task decomposition into subtasks.',
      payload: 'prompt (str), accountId (optional), model (str)',
      response: 'intent, intentConfidence, reasoning, subtasks[], rawRequest, rawResponse'
    },
    {
      route: '/api/agent/execute_subtask',
      method: 'POST',
      desc: 'Executes subtask by assigned specialist with SQL query & ₹ formatting.',
      payload: 'subtask (obj), agent (obj), prompt (str), accountId (optional)',
      response: 'success (bool), speechSummary (str), thoughtLog[], code (obj), executionOutput'
    },
    {
      route: '/api/fastapi/eva/synthesize',
      method: 'POST',
      desc: 'Final customer response synthesis. Zero DB for greetings; SQL audit for banking.',
      payload: 'intent (str), subtaskResults[], prompt (str), accountId (optional)',
      response: 'success (bool), customer_response (str), usedEngine (str), rawRequest, rawResponse'
    },
    {
      route: '/api/logs/step',
      method: 'POST',
      desc: 'Step validation logging into server runtime file and PostgreSQL audit table.',
      payload: 'source, level, stepNumber, stepName, status, message, details',
      response: 'success (bool), logged_at (ISO timestamp)'
    }
  ];

  apiTable.forEach((item) => {
    addNewPageIfNeeded(22);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(margin, y, pageWidth - (margin * 2), 19, 1, 1, 'FD');

    // Method pill
    doc.setFillColor(2, 132, 199);
    doc.roundedRect(margin + 2, y + 2, 12, 3.5, 0.5, 0.5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6);
    doc.setTextColor(255, 255, 255);
    doc.text(item.method, margin + 3.5, y + 4.5);

    doc.setFont('courier', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(15, 23, 42);
    doc.text(item.route, margin + 16, y + 4.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(71, 85, 105);

    doc.text(`Description: ${item.desc}`, margin + 3, y + 8.5);
    doc.text(`Request Body: ${item.payload}`, margin + 3, y + 12);
    doc.text(`Response: ${item.response}`, margin + 3, y + 15.5);

    y += 21;
  });

  // Section 5: Robustness, Error Handling & 2-Tier Fallback Rules
  addNewPageIfNeeded(35);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('5. 2-TIER LLM FALLBACK & STEP VALIDATION ENGINE', margin, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(51, 65, 85);
  const fallbackRules = [
    '• Primary Engine: Google Gemini 3.7 Flash via @google/genai SDK (server-side, latency target < 800ms).',
    '• Secondary Engine: Local Ollama runtime (model: phi3:mini) at OLLAMA_BASE_URL (armed automatically upon Gemini timeout/error).',
    '• Zero Database Access for Greetings: When intent is "greetings", database calls are completely bypassed (0 SQL queries) to prevent data leaks and reduce latency.',
    '• Dynamic Account ID Identification: Account IDs are strictly extracted from customer prompts. If no account ID is passed, the system requests account identification dynamically.',
    '• Currency Enactment: All balances, transactions, and statements are calculated and presented in Indian Rupees (INR / ₹) with standard lakhs/crores formatting.',
    '• Complete Auditability: Raw LLM request payloads and raw JSON responses are captured at every invocation for full traceability.'
  ];

  fallbackRules.forEach(rule => {
    const splitRule = doc.splitTextToSize(rule, pageWidth - (margin * 2));
    doc.text(splitRule, margin, y);
    y += splitRule.length * 3.8;
  });

  // Save the document
  doc.save('Banking_Harness_Architecture_Integration_Document.pdf');
}
