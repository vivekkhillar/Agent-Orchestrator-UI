/**
 * Dynamic Account ID Extractor
 * Extracts account identifiers strictly if present in the user's natural language prompt.
 * If no account ID is mentioned, returns null.
 */

export function extractAccountIdFromPrompt(prompt: string): string | null {
  if (!prompt || typeof prompt !== 'string') return null;

  // 1. Match standard ACC-XXXXX pattern (case-insensitive) e.g., "ACC-94820", "acc-55210", "ACC-1002"
  const accHyphenMatch = prompt.match(/\bACC[-\s]?([A-Za-z0-9]+)\b/i);
  if (accHyphenMatch && accHyphenMatch[1]) {
    return `ACC-${accHyphenMatch[1].toUpperCase()}`;
  }

  // 2. Match phrases like "account id ACC-94820", "account #94820", "account number 94820", "a/c 94820"
  const accountPhraseMatch = prompt.match(/\b(?:account(?:\s*(?:id|number|no\.?|#))?|a\/c)\s*[:=]?\s*([A-Za-z0-9-]+)\b/i);
  if (accountPhraseMatch && accountPhraseMatch[1]) {
    const rawVal = accountPhraseMatch[1].trim();
    // Exclude common false positives like "balance", "statement", "details", "info", "my", "this"
    const stopWords = ['balance', 'statement', 'details', 'info', 'summary', 'history', 'my', 'the', 'this', 'that', 'please', 'is', 'for'];
    if (!stopWords.includes(rawVal.toLowerCase())) {
      if (rawVal.toUpperCase().startsWith('ACC-')) {
        return rawVal.toUpperCase();
      } else if (rawVal.toUpperCase().startsWith('ACC')) {
        return `ACC-${rawVal.substring(3).toUpperCase()}`;
      } else if (/^\d+$/.test(rawVal)) {
        return `ACC-${rawVal}`;
      } else {
        return rawVal.toUpperCase();
      }
    }
  }

  // 3. Match 5-6 digit standalone numbers if preceded by keywords like "for", "of", "in" e.g. "balance for 94820"
  const numMatch = prompt.match(/\b(?:for|of|in|check|id)\s+(\d{4,6})\b/i);
  if (numMatch && numMatch[1]) {
    return `ACC-${numMatch[1]}`;
  }

  return null;
}
