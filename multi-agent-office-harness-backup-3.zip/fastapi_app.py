"""
FastAPI Multi-Agent Banking Orchestrator & Gateway (LangGraph Powered)
Boss Agent: EVA [0x1]
Sub-Agents: VK (Balance Specialist), RO (Statement Specialist)
Currency: INR (₹ - Indian Rupees)

Strict 2-Tier Fallback:
1. Gemini (gemini-3.7-flash)
2. Ollama (phi3:mini)
Raw Requests and Raw Responses captured for all invocations.
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging

from agent_vk_balance import router as vk_balance_router, query_account_balance, BalanceRequest
from agent_ro_statement import router as ro_statement_router, generate_account_statement, StatementRequest
from banking_orchestrator import run_banking_pipeline, invoke_llm_with_fallback, get_account_data, get_transactions_data

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("EVA_FastAPI")

app = FastAPI(
    title="Multi-Agent Banking Harness (FastAPI + LangGraph)",
    description="Boss EVA intent classification, routing to VK (Balance) and RO (Statement), and customer response synthesis with raw request/response logging.",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Sub-Agent FastAPI Routers
app.include_router(vk_balance_router)
app.include_router(ro_statement_router)


class CustomerQueryRequest(BaseModel):
    prompt: str = Field(..., description="Customer natural language request")
    account_id: Optional[str] = Field(default="ACC-94820", description="Bank account number")
    accountId: Optional[str] = Field(default=None, description="CamelCase alias for account_id")


class OrchestratedResponse(BaseModel):
    status: str
    identified_intent: str
    intent_confidence: float
    intent_reasoning: str
    assigned_agent: str
    boss_cabin: str = "Executive Cabin [0x1]"
    execution_result: Dict[str, Any]
    final_customer_response: str
    used_engine: str
    raw_requests: List[Dict[str, Any]]
    raw_responses: List[Dict[str, Any]]
    llm_invocations: List[Dict[str, Any]]
    timestamp: str


@app.get("/api/v1/health")
async def health_check():
    return {
        "status": "healthy",
        "orchestrator": "LangGraph Banking State Machine",
        "boss_agent": "EVA [0x1]",
        "sub_agents": {
            "VK": "Balance Inquiry Specialist (/api/v1/agent/vk/balance)",
            "RO": "Account Statement Specialist (/api/v1/agent/ro/statement)"
        },
        "llm_pipeline": "1st Gemini (gemini-3.7-flash) -> 2nd Ollama (phi3:mini)",
        "currency": "INR (₹)",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.post("/api/v1/orchestrator/dispatch", response_model=OrchestratedResponse)
@app.post("/api/agent/orchestrator/dispatch", response_model=OrchestratedResponse)
@app.post("/api/agent/orchestrate", response_model=OrchestratedResponse)
@app.post("/api/orchestrate", response_model=OrchestratedResponse)
async def dispatch_customer_query(req: CustomerQueryRequest):
    """
    Main LangGraph Gateway Endpoint:
    1. Boss EVA receives user query
    2. Identifies intent dynamically via LLM (Gemini -> fallback to Ollama phi3:mini)
    3. LangGraph conditional routing to specialized agent (VK or RO or Greeting)
    4. Synthesizes verified customer response delivered back in Indian Rupees (₹)
    5. Returns captured raw requests & responses
    """
    target_account = req.account_id or req.accountId or "ACC-94820"
    logger.info(f"Boss EVA LangGraph processing query: \"{req.prompt}\" for account {target_account}")

    # Execute LangGraph Pipeline
    pipeline_result = run_banking_pipeline(req.prompt, target_account)

    return OrchestratedResponse(
        status="SUCCESS",
        identified_intent=pipeline_result.get("intent", "other"),
        intent_confidence=pipeline_result.get("intent_confidence", 0.98),
        intent_reasoning=pipeline_result.get("intent_reasoning", "LLM classified semantic intent"),
        assigned_agent=pipeline_result.get("assigned_agent", "Boss EVA"),
        boss_cabin="Executive Cabin [0x1]",
        execution_result=pipeline_result.get("specialist_output", {}),
        final_customer_response=pipeline_result.get("final_customer_response", ""),
        used_engine=pipeline_result.get("used_engine", "gemini-3.7-flash"),
        raw_requests=pipeline_result.get("raw_requests", []),
        raw_responses=pipeline_result.get("raw_responses", []),
        llm_invocations=pipeline_result.get("llm_invocations", []),
        timestamp=datetime.utcnow().isoformat()
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("fastapi_app:app", host="0.0.0.0", port=8000, reload=True)
