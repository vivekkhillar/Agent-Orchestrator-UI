"""
Pytest Test Suite for FastAPI Banking Multi-Agent System
Tests VK Balance Endpoint, RO Statement Endpoint, and EVA Intent Routing
"""

import pytest
import asyncio
from agent_vk_balance import query_account_balance, BalanceRequest
from agent_ro_statement import generate_account_statement, StatementRequest
from banking_orchestrator import EVAOrchestrator

@pytest.fixture
def orchestrator():
    return EVAOrchestrator()

def test_eva_intent_classification(orchestrator):
    # Test Balance Intent
    intent1, conf1, agent1 = orchestrator.classify_intent("What is my current available balance for ACC-94820?")
    assert intent1 == "balance_inquiry"
    assert agent1 == "VK"
    assert conf1 >= 0.90

    # Test Statement Intent
    intent2, conf2, agent2 = orchestrator.classify_intent("Please send me last 30 days bank statement and transactions")
    assert intent2 == "account_statement"
    assert agent2 == "RO"
    assert conf2 >= 0.90

    # Test Combined Intent
    intent3, conf3, agent3 = orchestrator.classify_intent("Check my balance and print transaction statement")
    assert intent3 == "general_banking"
    assert agent3 == "VK & RO"

    # Test Greeting Intent (Must NOT call VK or RO)
    intent4, conf4, agent4 = orchestrator.classify_intent("hi")
    assert intent4 == "greeting"
    assert "NONE" in agent4

    # Test Unrecognized Query Intent (Must NOT call VK or RO)
    intent5, conf5, agent5 = orchestrator.classify_intent("tell me a random fact about space")
    assert intent5 == "unrecognized"
    assert "NONE" in agent5

    # Test LLM Invocation Method
    llm_res_greeting = orchestrator.classify_intent_with_llm("hello, good morning!")
    assert llm_res_greeting["intent"] == "greeting"
    assert "Direct" in llm_res_greeting["assignedAgentName"] or "NONE" in llm_res_greeting["assignedAgentName"]

    llm_res_balance = orchestrator.classify_intent_with_llm("how much money is in my savings?")
    assert llm_res_balance["intent"] == "balance_inquiry"
    assert "VK" in llm_res_balance["assignedAgentName"]

    llm_res_statement = orchestrator.classify_intent_with_llm("export all monthly outflows and credit card purchases")
    assert llm_res_statement["intent"] == "account_statement"
    assert "RO" in llm_res_statement["assignedAgentName"]

@pytest.mark.asyncio
async def test_vk_balance_inquiry():
    req = BalanceRequest(account_id="ACC-94820")
    res = await query_account_balance(req)
    
    assert res.account_id == "ACC-94820"
    assert res.available_balance == 139430.50
    assert res.checking_balance == 98450.50
    assert res.savings_balance == 44400.00
    assert res.pending_holds == 3420.00
    assert res.status == "ACTIVE_VERIFIED"
    assert res.processed_by == "Agent VK (Balance Specialist)"

@pytest.mark.asyncio
async def test_ro_statement_generation():
    req = StatementRequest(account_id="ACC-94820", days_period=30)
    res = await generate_account_statement(req)
    
    assert res.account_id == "ACC-94820"
    assert res.transaction_count == 5
    assert res.total_credits == 64200.00
    assert res.total_debits == 18420.00
    assert res.net_change == 45780.00
    assert res.closing_balance == 142850.50
    assert "OFFICIAL ACCOUNT STATEMENT" in res.ascii_table
    assert res.generated_by == "Agent RO (Account Statement Specialist)"

def test_eva_customer_response_synthesis(orchestrator):
    mock_balance_data = {
        "available_balance": 139430.50,
        "checking_balance": 98450.50,
        "savings_balance": 44400.00,
        "pending_holds": 3420.00,
        "currency": "USD"
    }
    response_text = orchestrator.synthesize_customer_response("balance_inquiry", "ACC-94820", mock_balance_data)
    assert "Boss EVA" in response_text
    assert "VK" in response_text
    assert "$139,430.50" in response_text
