// Web Audio API Synthesizer for subtle retro terminal UI sound effects
class SoundEngine {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private getContext(): AudioContext | null {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public playBeep(freq: number = 600, duration: number = 0.08, type: OscillatorType = 'sine') {
    if (!this.enabled) return;
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // safe fallback
    }
  }

  public playDispatch() {
    this.playBeep(440, 0.06, 'triangle');
    setTimeout(() => this.playBeep(880, 0.08, 'triangle'), 60);
  }

  public playTaskComplete() {
    this.playBeep(523.25, 0.08, 'sine'); // C5
    setTimeout(() => this.playBeep(659.25, 0.08, 'sine'), 80); // E5
    setTimeout(() => this.playBeep(783.99, 0.12, 'sine'), 160); // G5
  }

  public playTyping() {
    this.playBeep(1200 + Math.random() * 400, 0.02, 'square');
  }

  public playFootstep() {
    this.playBeep(180 + Math.random() * 40, 0.03, 'sine');
  }

  public playSuccess() {
    this.playBeep(523.25, 0.08, 'sine'); // C5
    setTimeout(() => this.playBeep(659.25, 0.08, 'sine'), 70); // E5
    setTimeout(() => this.playBeep(783.99, 0.08, 'sine'), 140); // G5
    setTimeout(() => this.playBeep(1046.50, 0.18, 'sine'), 210); // C6
  }
}

export const soundFx = new SoundEngine();
