"""
Agent VK: Dedicated Balance Inquiry Module (FastAPI)
Author: VK (Balance Inquiry Specialist)
Endpoint: POST /api/v1/agent/vk/balance
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, Optional, List
from datetime import datetime
import logging

router = APIRouter(prefix="/api/v1/agent/vk", tags=["Balance Inquiry"])
logger = logging.getLogger("AgentVK")

# Easily Configurable Mock Financial Ledger Database
ACCOUNT_DATABASE: Dict[str, Dict] = {
    "ACC-94820": {
        "account_id": "ACC-94820",
        "account_name": "Primary Treasury & Operating",
        "currency": "USD",
        "checking_balance": 98450.50,
        "savings_balance": 44400.00,
        "pending_holds": 3420.00,
        "credit_limit": 50000.00,
        "last_reconciled": datetime.utcnow().isoformat(),
        "status": "ACTIVE_VERIFIED"
    },
    "ACC-10029": {
        "account_id": "ACC-10029",
        "account_name": "Global Multi-Currency Corporate",
        "currency": "USD",
        "checking_balance": 245000.00,
        "savings_balance": 180000.00,
        "pending_holds": 12500.00,
        "fx_rates": {
            "EUR": 0.92,
            "GBP": 0.78,
            "JPY": 154.20
        },
        "last_reconciled": datetime.utcnow().isoformat(),
        "status": "ACTIVE_VERIFIED"
    }
}

class BalanceRequest(BaseModel):
    account_id: str = Field(default="ACC-94820", description="Target bank account number")
    include_fx: bool = Field(default=True, description="Include multi-currency balances")

class BalanceResponse(BaseModel):
    account_id: str
    account_name: str
    currency: str
    available_balance: float
    total_ledger_balance: float
    checking_balance: float
    savings_balance: float
    pending_holds: float
    status: str
    timestamp: str
    processed_by: str = "Agent VK (Balance Specialist)"

@router.post("/balance", response_model=BalanceResponse)
async def query_account_balance(req: BalanceRequest):
    """
    VK's dedicated balance inquiry endpoint.
    Called by EVA Banking Orchestrator when balance intent is identified.
    """
    logger.info(f"VK Processing balance inquiry for account: {req.account_id}")
    record = ACCOUNT_DATABASE.get(req.account_id)
    if not record:
        # Dynamic fallback for arbitrary account numbers
        record = {
            "account_id": req.account_id,
            "account_name": "Standard Operating & Treasury",
            "currency": "USD",
            "checking_balance": 65000.00,
            "savings_balance": 35000.00,
            "pending_holds": 1500.00,
            "status": "ACTIVE_VERIFIED",
            "last_reconciled": datetime.utcnow().isoformat()
        }

    total_ledger = record["checking_balance"] + record["savings_balance"]
    net_available = total_ledger - record["pending_holds"]

    return BalanceResponse(
        account_id=record["account_id"],
        account_name=record["account_name"],
        currency=record["currency"],
        available_balance=round(net_available, 2),
        total_ledger_balance=round(total_ledger, 2),
        checking_balance=round(record["checking_balance"], 2),
        savings_balance=round(record["savings_balance"], 2),
        pending_holds=round(record["pending_holds"], 2),
        status=record["status"],
        timestamp=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    )

if __name__ == "__main__":
    import asyncio
    sample_res = asyncio.run(query_account_balance(BalanceRequest(account_id="ACC-94820")))
    print("=== VK Balance Inquiry Query Result ===")
    print(f"Account: {sample_res.account_id} | {sample_res.account_name}")
    print(f"Available Funds: ${sample_res.available_balance:,.2f} {sample_res.currency}")
    print(f"Total Ledger:    ${sample_res.total_ledger_balance:,.2f} {sample_res.currency}")
    print(f"Checking:        ${sample_res.checking_balance:,.2f}")
    print(f"Savings:         ${sample_res.savings_balance:,.2f}")
    print(f"Pending Holds:   ${sample_res.pending_holds:,.2f}")
