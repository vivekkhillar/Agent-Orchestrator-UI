import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Flag to track whether Gemini API key is valid or revoked/leaked
let isGeminiKeyFunctional: boolean | null = null;

// Lazy GoogleGenAI initialization
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY || isGeminiKeyFunctional === false) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Health & Environment check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasGeminiKey: !!process.env.GEMINI_API_KEY && isGeminiKeyFunctional !== false,
    geminiModel: 'gemini-3.7-flash',
    isGeminiActive: isGeminiKeyFunctional !== false,
    timestamp: Date.now()
  });
});

// Ollama Connection Check & Proxy
app.post('/api/ollama/status', async (req, res) => {
  const endpoint = req.body?.endpoint || 'http://localhost:11434';
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);
    
    const response = await fetch(`${endpoint}/api/tags`, {
      method: 'GET',
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (response.ok) {
      const data = await response.json();
      res.json({
        connected: true,
        endpoint,
        models: data.models || [{ name: 'phi3:mini' }],
        message: 'Connected to local Ollama instance'
      });
    } else {
      res.json({
        connected: false,
        endpoint,
        models: [{ name: 'phi3:mini' }],
        message: `Ollama returned status ${response.status}. Using high-efficiency fallback emulator.`
      });
    }
  } catch (err: any) {
    res.json({
      connected: false,
      endpoint,
      models: [{ name: 'phi3:mini' }, { name: 'llama3:8b' }],
      message: 'Local Ollama Docker container not reachable on ' + endpoint + '. Harness fallback engine active.'
    });
  }
});

// Supervisor EVA Banking Orchestration Endpoint
app.post('/api/agent/orchestrate', async (req, res) => {
  const { prompt, model = 'gemini-3.7-flash', customInstructions } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  const promptLower = prompt.toLowerCase();
  
  // Intent Classification Engine
  const isBalanceIntent = 
    promptLower.includes('balance') || 
    promptLower.includes('available fund') || 
    promptLower.includes('how much') || 
    promptLower.includes('savings') || 
    promptLower.includes('checking account') ||
    promptLower.includes('ledger balance') ||
    promptLower.includes('hold');

  const isStatementIntent = 
    promptLower.includes('statement') || 
    promptLower.includes('transaction') || 
    promptLower.includes('history') || 
    promptLower.includes('debit') || 
    promptLower.includes('credit') || 
    promptLower.includes('pdf') || 
    promptLower.includes('quarterly') || 
    promptLower.includes('annual') ||
    promptLower.includes('expense') ||
    promptLower.includes('tax');

  let detectedIntent: 'balance_inquiry' | 'account_statement' | 'general_banking' = 'balance_inquiry';
  let targetAgentId = 'agent_vk';
  let targetAgentName = 'VK';

  if (isBalanceIntent && isStatementIntent) {
    detectedIntent = 'general_banking';
    targetAgentId = 'agent_vk';
    targetAgentName = 'VK & RO';
  } else if (isStatementIntent) {
    detectedIntent = 'account_statement';
    targetAgentId = 'agent_ro';
    targetAgentName = 'RO';
  } else {
    detectedIntent = 'balance_inquiry';
    targetAgentId = 'agent_vk';
    targetAgentName = 'VK';
  }

  // Attempt Gemini API if key is present and functional
  const ai = getGenAI();
  if (ai && (!model || model.includes('gemini'))) {
    try {
      const systemInstruction = `You are EVA, Lead Banking Orchestrator & Supervisor [0x1].
You receive user banking requests and route them to dedicated specialized agents:
- VK (agent_vk): Dedicated exclusively to Balance Inquiry Intent (checking available balance, savings, ledger breakdown, FX rates).
- RO (agent_ro): Dedicated exclusively to Account Statement Intent (generating statements, transaction history, PDF ledgers, categorizing debits/credits).

Classify the user intent (${detectedIntent}) and decompose the request into 2 to 4 focused subtasks for the dedicated agent(s).

Return strict JSON:
{
  "intent": "${detectedIntent}",
  "intentConfidence": 0.98,
  "assignedAgentName": "${targetAgentName}",
  "supervisorPlan": "EVA's architectural orchestration plan routing to dedicated agent(s)",
  "subtasks": [
    {
      "id": "subtask_1",
      "title": "Short descriptive title",
      "description": "Specific task requirements and parameters",
      "assignedAgentId": "${targetAgentId}",
      "category": "python",
      "dependencies": [],
      "targetFile": "agent_${detectedIntent === 'balance_inquiry' ? 'vk_balance' : 'ro_statement'}.py",
      "language": "python"
    }
  ]
}`;

      const geminiResponse = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: `Decompose banking assignment: "${prompt}"\n${customInstructions ? `Additional: ${customInstructions}` : ''}`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.2
        }
      });

      const text = geminiResponse.text || '{}';
      const parsed = JSON.parse(text);
      isGeminiKeyFunctional = true;
      return res.json({
        success: true,
        provider: 'gemini-3.7-flash',
        intent: parsed.intent || detectedIntent,
        intentConfidence: parsed.intentConfidence || 0.98,
        assignedAgentName: parsed.assignedAgentName || targetAgentName,
        plan: parsed.supervisorPlan || `EVA classified intent as ${detectedIntent.toUpperCase()} and routed exclusively to ${targetAgentName}.`,
        subtasks: parsed.subtasks || []
      });
    } catch (err: any) {
      if (err?.message?.includes('403') || err?.message?.includes('leaked') || err?.message?.includes('PERMISSION_DENIED')) {
        isGeminiKeyFunctional = false;
      }
    }
  }

  // Deterministic FastAPI Banking Orchestrator Subtask Generator
  let generatedSubtasks = [];

  if (detectedIntent === 'balance_inquiry') {
    generatedSubtasks = [
      {
        id: `task_${Date.now()}_1`,
        title: "FastAPI Balance Schema & Account Lookup",
        description: `Parse account parameters from "${prompt.slice(0, 70)}...". Query ledger database and compute available vs locked balance.`,
        assignedAgentId: 'agent_vk',
        category: 'python',
        dependencies: [],
        targetFile: 'agent_vk_balance.py',
        language: 'python'
      },
      {
        id: `task_${Date.now()}_2`,
        title: "Multi-Currency Reconciliation & Hold Calculation",
        description: `Reconcile pending holds, compute real-time FX conversions (USD/EUR/GBP), and calculate net available funds.`,
        assignedAgentId: 'agent_vk',
        category: 'python',
        dependencies: [`task_${Date.now()}_1`],
        targetFile: 'agent_vk_balance.py',
        language: 'python'
      },
      {
        id: `task_${Date.now()}_3`,
        title: "FastAPI Endpoint Serialization & Deliverable Packaging",
        description: `Wrap results in FastAPI ResponseModel and prepare verified balance payload for Boss EVA submission.`,
        assignedAgentId: 'agent_vk',
        category: 'python',
        dependencies: [`task_${Date.now()}_2`],
        targetFile: 'fastapi_app.py',
        language: 'python'
      }
    ];
  } else if (detectedIntent === 'account_statement') {
    generatedSubtasks = [
      {
        id: `task_${Date.now()}_1`,
        title: "FastAPI Statement Query & Date Range Ingestion",
        description: `Filter transaction ledger across requested period for "${prompt.slice(0, 70)}...". Extract debits, credits, and merchant tags.`,
        assignedAgentId: 'agent_ro',
        category: 'python',
        dependencies: [],
        targetFile: 'agent_ro_statement.py',
        language: 'python'
      },
      {
        id: `task_${Date.now()}_2`,
        title: "Expense Categorization & Running Balance Computation",
        description: `Aggregate category spend (Payroll, Cloud, Operations), calculate running balance after each entry, and verify checksums.`,
        assignedAgentId: 'agent_ro',
        category: 'python',
        dependencies: [`task_${Date.now()}_1`],
        targetFile: 'agent_ro_statement.py',
        language: 'python'
      },
      {
        id: `task_${Date.now()}_3`,
        title: "FastAPI Formatted Statement & PDF/ASCII Ledger Generation",
        description: `Compile printable ASCII table, JSON artifact, and download links ready for submission to Boss EVA.`,
        assignedAgentId: 'agent_ro',
        category: 'python',
        dependencies: [`task_${Date.now()}_2`],
        targetFile: 'fastapi_app.py',
        language: 'python'
      }
    ];
  } else {
    // Dual Banking Inquiry (Balance via VK + Statement via RO)
    generatedSubtasks = [
      {
        id: `task_${Date.now()}_1`,
        title: "VK: Live Balance Computation & Available Ledger Extraction",
        description: `VK extracts current savings, checking, and pending balance status for "${prompt.slice(0, 60)}".`,
        assignedAgentId: 'agent_vk',
        category: 'python',
        dependencies: [],
        targetFile: 'agent_vk_balance.py',
        language: 'python'
      },
      {
        id: `task_${Date.now()}_2`,
        title: "RO: Statement Compilation & Recent Transaction Ledger",
        description: `RO compiles recent transaction history, debit/credit totals, and merchant metadata.`,
        assignedAgentId: 'agent_ro',
        category: 'python',
        dependencies: [`task_${Date.now()}_1`],
        targetFile: 'agent_ro_statement.py',
        language: 'python'
      }
    ];
  }

  return res.json({
    success: true,
    provider: model.startsWith('ollama') ? 'ollama (FastAPI phi3 local)' : 'FastAPI Banking Orchestrator',
    intent: detectedIntent,
    intentConfidence: 0.99,
    assignedAgentName: targetAgentName,
    plan: `Boss EVA analyzed customer query. Identified intent: [${detectedIntent.toUpperCase()}]. Routing task exclusively to dedicated specialist ${targetAgentName}.`,
    subtasks: generatedSubtasks
  });
});

// Sub-Agent Code & Execution Generation
app.post('/api/agent/execute_subtask', async (req, res) => {
  const { subtask, agent, prompt, context } = req.body;

  if (!subtask || !agent) {
    return res.status(400).json({ error: 'Subtask and agent are required' });
  }

  // If Gemini API is configured and functional
  const ai = getGenAI();
  if (ai && (!agent.model || agent.model.includes('gemini'))) {
    try {
      const systemInstruction = `You are ${agent.name}, ${agent.title}.
Your role is: ${agent.role}.
Generate realistic, clean, production-grade code and a step-by-step thought log for this subtask:
Title: ${subtask.title}
Description: ${subtask.description}
Target File: ${subtask.targetFile || 'solution.py'}
Language: ${subtask.language || 'python'}

Output valid JSON matching:
{
  "thoughtLog": [
    "Step 1 thought...",
    "Step 2 thought...",
    "Step 3 thought..."
  ],
  "speechSummary": "Short 1-sentence statement to say to team",
  "filename": "${subtask.targetFile || 'solution.py'}",
  "language": "${subtask.language || 'python'}",
  "code": "executable code snippet",
  "executionOutput": "Simulated terminal output / test results / benchmark"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: `Implement subtask "${subtask.title}" for prompt: "${prompt}". Context from previous steps: ${JSON.stringify(context || {})}`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: agent.temperature || 0.3
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      isGeminiKeyFunctional = true;
      return res.json({
        success: true,
        thoughtLog: parsed.thoughtLog || [`Analyzed requirements for ${subtask.title}`, `Crafted solution architecture`, `Validated syntax and test fixtures`],
        speechSummary: parsed.speechSummary || `Completed ${subtask.title} with full test coverage.`,
        code: {
          filename: parsed.filename || subtask.targetFile || 'solution.py',
          language: parsed.language || 'python',
          content: parsed.code || '# Code generated\nprint("Task complete")'
        },
        executionOutput: parsed.executionOutput || 'Process exited with code 0. All 12 assertions passed in 0.042s.'
      });
    } catch (err: any) {
      if (err?.message?.includes('403') || err?.message?.includes('leaked') || err?.message?.includes('PERMISSION_DENIED')) {
        isGeminiKeyFunctional = false;
      }
    }
  }

  // High quality domain-specific code generators for Python, TS, QA, Data, DevOps
  let codeContent = '';
  let language = subtask.language || 'python';
  let filename = subtask.targetFile || 'solution.py';
  let executionOutput = '';
  let speechSummary = '';
  const thoughts: string[] = [];

  switch (agent.role) {
    case 'balance_specialist':
    case 'python_dev':
      if (agent.id === 'agent_vk' || agent.role === 'balance_specialist') {
        filename = 'agent_vk_balance.py';
        language = 'python';
        speechSummary = `VK computed real-time ledger balance, FX rates, and pending holds!`;
        thoughts.push(`FastAPI: Ingesting account token & validating PCI-DSS compliance`);
        thoughts.push(`Executing SQL/Ledger query for account ACC-94820`);
        thoughts.push(`Calculating available balance ($142,850.50) vs pending holds ($3,420.00)`);
        thoughts.push(`Formatting Pydantic BalanceResponse schema`);
        codeContent = `"""
Agent VK: Dedicated Balance Inquiry Service (FastAPI)
Author: VK (Balance Inquiry Specialist)
Endpoint: POST /api/v1/agent/vk/balance
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Dict, Optional, List
from datetime import datetime
import logging

router = APIRouter(prefix="/api/v1/agent/vk", tags=["Balance Inquiry"])
logger = logging.getLogger("AgentVK")

# In-Memory Mock Financial Ledger
ACCOUNT_DATABASE = {
    "ACC-94820": {
        "account_id": "ACC-94820",
        "account_name": "Primary Treasury & Operating",
        "currency": "USD",
        "checking_balance": 98450.50,
        "savings_balance": 44400.00,
        "pending_holds": 3420.00,
        "credit_limit": 50000.00,
        "last_reconciled": datetime.utcnow().isoformat(),
        "status": "ACTIVE_VERIFIED"
    },
    "ACC-10029": {
        "account_id": "ACC-10029",
        "account_name": "Global Multi-Currency Corporate",
        "currency": "USD",
        "checking_balance": 245000.00,
        "savings_balance": 180000.00,
        "pending_holds": 12500.00,
        "fx_balances": {
            "EUR": 118400.00,
            "GBP": 82100.00
        },
        "last_reconciled": datetime.utcnow().isoformat(),
        "status": "ACTIVE_VERIFIED"
    }
}

class BalanceRequest(BaseModel):
    account_id: str = Field(default="ACC-94820", description="Bank account number")
    include_fx: bool = Field(default=True, description="Include multi-currency balances")

class BalanceResponse(BaseModel):
    account_id: str
    account_name: str
    currency: str
    available_balance: float
    total_ledger_balance: float
    checking_balance: float
    savings_balance: float
    pending_holds: float
    status: str
    timestamp: str
    processed_by: str = "Agent VK (Balance Specialist)"

@router.post("/balance", response_model=BalanceResponse)
async def query_account_balance(req: BalanceRequest):
    """
    VK's dedicated balance inquiry endpoint.
    Called by EVA Banking Orchestrator when balance intent is identified.
    """
    logger.info(f"VK Processing balance inquiry for {req.account_id}")
    record = ACCOUNT_DATABASE.get(req.account_id)
    if not record:
        # Fallback dynamic account builder for test accounts
        record = {
            "account_id": req.account_id,
            "account_name": "Standard Checking & Savings",
            "currency": "USD",
            "checking_balance": 52400.00,
            "savings_balance": 25000.00,
            "pending_holds": 1200.00,
            "status": "ACTIVE_VERIFIED",
            "last_reconciled": datetime.utcnow().isoformat()
        }

    total_ledger = record["checking_balance"] + record["savings_balance"]
    net_available = total_ledger - record["pending_holds"]

    return BalanceResponse(
        account_id=record["account_id"],
        account_name=record["account_name"],
        currency=record["currency"],
        available_balance=round(net_available, 2),
        total_ledger_balance=round(total_ledger, 2),
        checking_balance=round(record["checking_balance"], 2),
        savings_balance=round(record["savings_balance"], 2),
        pending_holds=round(record["pending_holds"], 2),
        status=record["status"],
        timestamp=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    )

if __name__ == "__main__":
    import asyncio
    sample_res = asyncio.run(query_account_balance(BalanceRequest(account_id="ACC-94820")))
    print("=== VK Balance Inquiry Query Result ===")
    print(f"Account: {sample_res.account_id} | {sample_res.account_name}")
    print(f"Available Funds: \${sample_res.available_balance:,.2f} {sample_res.currency}")
    print(f"Total Ledger:    \${sample_res.total_ledger_balance:,.2f} {sample_res.currency}")
    print(f"Checking:        \${sample_res.checking_balance:,.2f}")
    print(f"Savings:         \${sample_res.savings_balance:,.2f}")
    print(f"Pending Holds:   \${sample_res.pending_holds:,.2f}")
`;
        executionOutput = `[FASTAPI ROUTER] POST /api/v1/agent/vk/balance -> 200 OK
=== VK Balance Inquiry Result ===
Account ID       : ACC-94820 (Primary Treasury & Operating)
Available Funds  : $139,430.50 USD
Total Ledger     : $142,850.50 USD
Checking Balance : $98,450.50 USD
Savings Balance  : $44,400.00 USD
Pending Holds    : $3,420.00 USD (Reconciled)
Execution Time   : 0.038s | Verification: SHA256-PASSED | Assigned: VK`;
        break;
      }
      filename = 'async_service.py';
      language = 'python';
      speechSummary = `Built async Python pipeline with worker pool and error handling!`;
      thoughts.push(`Analyzing concurrency parameters and connection pooling`);
      thoughts.push(`Constructing AsyncEngine with exponential backoff & task semaphore`);
      thoughts.push(`Adding type annotations and dataclass payload serialization`);
      codeContent = `# Standard Python Async Pipeline`;
      executionOutput = `Execution Time: 0.142s | Memory RSS: 18.4MB | Status: 200 OK`;
      break;

    case 'statement_specialist':
    case 'ts_dev':
      if (agent.id === 'agent_ro' || agent.role === 'statement_specialist') {
        filename = 'agent_ro_statement.py';
        language = 'python';
        speechSummary = `RO compiled 30-day transaction ledger, category spend, and ASCII/PDF statement!`;
        thoughts.push(`FastAPI: Filtering transaction ledger for date range (last 30 days)`);
        thoughts.push(`Aggregating debits ($18,420.00) vs credits ($64,200.00)`);
        thoughts.push(`Categorizing line items: Vendor Payouts, AWS Cloud, Stripe Inflows`);
        thoughts.push(`Generating formatted statement ledger ready for Boss EVA`);
        codeContent = `"""
Agent RO: Dedicated Account Statement Service (FastAPI)
Author: RO (Account Statement Specialist)
Endpoint: POST /api/v1/agent/ro/statement
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging

router = APIRouter(prefix="/api/v1/agent/ro", tags=["Account Statement"])
logger = logging.getLogger("AgentRO")

# Mock Transaction Database
MOCK_TRANSACTIONS = [
    {"id": "TXN_1091", "date": "2026-08-22", "description": "STRIPE PAYOUT INFLOW", "category": "Revenue", "amount": 42500.00, "type": "CREDIT", "balance_after": 142850.50},
    {"id": "TXN_1090", "date": "2026-08-20", "description": "AMAZON WEB SERVICES", "category": "Cloud Infra", "amount": -4820.00, "type": "DEBIT", "balance_after": 100350.50},
    {"id": "TXN_1089", "date": "2026-08-18", "description": "GUSTO PAYROLL DIRECT", "category": "Payroll", "amount": -12400.00, "type": "DEBIT", "balance_after": 105170.50},
    {"id": "TXN_1088", "date": "2026-08-14", "description": "CLIENT WIRE ACQUISITION", "category": "Revenue", "amount": 21700.00, "type": "CREDIT", "balance_after": 117570.50},
    {"id": "TXN_1087", "date": "2026-08-08", "description": "GITHUB & AI API TOOLS", "category": "SaaS Tools", "amount": -1200.00, "type": "DEBIT", "balance_after": 95870.50}
]

class StatementRequest(BaseModel):
    account_id: str = Field(default="ACC-94820", description="Account ID")
    days_period: int = Field(default=30, description="Statement duration in days")
    format_type: str = Field(default="json_and_table", description="Output format: json, ascii, pdf")

class TransactionItem(BaseModel):
    id: str
    date: str
    description: str
    category: str
    amount: float
    type: str
    balance_after: float

class StatementResponse(BaseModel):
    statement_id: str
    account_id: str
    period: str
    opening_balance: float
    closing_balance: float
    total_credits: float
    total_debits: float
    net_change: float
    transaction_count: int
    transactions: List[TransactionItem]
    ascii_table: str
    generated_by: str = "Agent RO (Account Statement Specialist)"

@router.post("/statement", response_model=StatementResponse)
async def generate_account_statement(req: StatementRequest):
    """
    RO's dedicated statement generation endpoint.
    Called by EVA Banking Orchestrator when statement intent is identified.
    """
    logger.info(f"RO Generating statement for {req.account_id} over {req.days_period} days")
    
    total_credits = sum(t["amount"] for t in MOCK_TRANSACTIONS if t["amount"] > 0)
    total_debits = sum(abs(t["amount"]) for t in MOCK_TRANSACTIONS if t["amount"] < 0)
    opening_bal = 95870.50
    closing_bal = 142850.50

    # Build ASCII Statement Table
    table_lines = [
        "--------------------------------------------------------------------------------",
        f"OFFICIAL ACCOUNT STATEMENT | ACCOUNT: {req.account_id} | LAST {req.days_period} DAYS",
        "--------------------------------------------------------------------------------",
        f"{'DATE':<12} {'TXN ID':<10} {'DESCRIPTION':<28} {'TYPE':<8} {'AMOUNT ($)':>12}",
        "--------------------------------------------------------------------------------"
    ]
    for t in MOCK_TRANSACTIONS:
        sign = "+" if t["amount"] > 0 else "-"
        table_lines.append(
            f"{t['date']:<12} {t['id']:<10} {t['description']:<28} {t['type']:<8} {sign}\${abs(t['amount']):>10,.2f}"
        )
    table_lines.append("--------------------------------------------------------------------------------")
    table_lines.append(f"TOTAL CREDITS: +\${total_credits:,.2f} | TOTAL DEBITS: -\${total_debits:,.2f} | NET: +\${total_credits-total_debits:,.2f}")
    table_lines.append(f"CLOSING BALANCE: \${closing_bal:,.2f} USD")
    table_lines.append("--------------------------------------------------------------------------------")

    return StatementResponse(
        statement_id=f"STM-{datetime.utcnow().strftime('%Y%m%d')}-094",
        account_id=req.account_id,
        period=f"Last {req.days_period} Days ({datetime.utcnow().strftime('%B %Y')})",
        opening_balance=opening_bal,
        closing_balance=closing_bal,
        total_credits=total_credits,
        total_debits=total_debits,
        net_change=total_credits - total_debits,
        transaction_count=len(MOCK_TRANSACTIONS),
        transactions=[TransactionItem(**t) for t in MOCK_TRANSACTIONS],
        ascii_table="\\n".join(table_lines)
    )

if __name__ == "__main__":
    import asyncio
    stmt = asyncio.run(generate_account_statement(StatementRequest(account_id="ACC-94820")))
    print(stmt.ascii_table)
`;
        executionOutput = `[FASTAPI ROUTER] POST /api/v1/agent/ro/statement -> 200 OK
Statement ID: STM-20260824-094 | Account: ACC-94820
Transactions Ingested: 5 | Period: Last 30 Days
Total Credits: +$64,200.00 | Total Debits: -$18,420.00 | Net Change: +$45,780.00
Closing Balance: $142,850.50 USD
Execution Time: 0.042s | Checksum: VALIDATED | Assigned: RO`;
        break;
      }
      filename = 'AgentDashboardView.tsx';
      language = 'typescript';
      speechSummary = `Constructed typed React component with live WebSocket telemetry!`;
      codeContent = `// TS Component`;
      executionOutput = `TypeScript compilation succeeded.`;
      break;
      executionOutput = `TypeScript Check: 0 Errors | TS Compilation Succeeded (tsc --noEmit)
Bundle Size: 2.1 kB gzipped | Tree-shaken exports: [AgentTelemetryCard, AgentMetric]`;
      break;

    case 'qa_engineer':
      filename = 'test_harness_suite.py';
      language = 'python';
      speechSummary = `Executed 18 pytest test cases with 100% boundary assertion pass rate!`;
      thoughts.push(`Creating pytest fixtures for mock payloads and rate limiters`);
      thoughts.push(`Adding parameterized test cases for edge errors and network timeouts`);
      thoughts.push(`Asserting semaphore limits under simulated burst loads`);
      codeContent = `"""
Pytest Test Suite & Resilience Verification
Author: Rex Sterling (QA & Test Specialist)
"""

import pytest
import asyncio
import time
from async_service import ConcurrentWorkerPool, JobPayload

@pytest.fixture
def worker_pool():
    return ConcurrentWorkerPool(concurrency=3, rate_limit_rps=50.0)

@pytest.mark.asyncio
async def test_worker_concurrency_limit(worker_pool):
    jobs = [JobPayload(f"TEST_{i}", f"https://mock.service/{i}") for i in range(8)]
    start = time.perf_counter()
    results = await worker_pool.run_batch(jobs)
    elapsed = time.perf_counter() - start

    assert len(results) == 8
    assert all(r["status"] == "SUCCESS" for r in results)
    assert worker_pool.processed_count == 8
    assert elapsed > 0.05, "Rate limiter timing invariant satisfied"

@pytest.mark.asyncio
@pytest.mark.parametrize("retry_count", [1, 3, 5])
async def test_job_retry_parameterization(worker_pool, retry_count):
    job = JobPayload("RET_01", "https://mock.service/retry", retries=retry_count)
    res = await worker_pool.fetch_item(job)
    assert res["status"] == "SUCCESS"
    assert "confidence_score" in res
    assert res["confidence_score"] > 0.90

def test_job_payload_immutability():
    payload = JobPayload("IMMUT_01", "https://mock.service/immut", priority=2)
    assert payload.retries == 3
    assert payload.priority == 2
`;
      executionOutput = `============================= test session starts ==============================
platform linux -- Python 3.11.8, pytest-8.1.1, asyncio-0.23.5
rootdir: /workspace/harness
collected 5 items

test_harness_suite.py::test_worker_concurrency_limit PASSED              [ 20%]
test_harness_suite.py::test_job_retry_parameterization[1] PASSED         [ 40%]
test_harness_suite.py::test_job_retry_parameterization[3] PASSED         [ 60%]
test_harness_suite.py::test_job_retry_parameterization[5] PASSED         [ 80%]
test_harness_suite.py::test_job_payload_immutability PASSED              [100%]

============================== 5 passed in 0.08s ===============================`;
      break;

    case 'data_analyst':
      filename = 'analytics_pipeline.py';
      language = 'python';
      speechSummary = `Engineered Pandas time-series aggregation & statistical distribution models!`;
      thoughts.push(`Structuring streaming event ingestion schema`);
      thoughts.push(`Computing rolling quantiles and throughput percentiles`);
      thoughts.push(`Generating vectorized summary statistics`);
      codeContent = `"""
Pandas Data Stream & Analytics Pipeline
Author: Maya Patel (Data & Algorithm Researcher)
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_telemetry_dataset(num_records: int = 500) -> pd.DataFrame:
    np.random.seed(42)
    base_time = datetime.now() - timedelta(minutes=60)
    timestamps = [base_time + timedelta(seconds=i*7.2) for i in range(num_records)]
    
    df = pd.DataFrame({
        "timestamp": timestamps,
        "agent_id": np.random.choice(["agent_python", "agent_ts", "agent_qa", "agent_data"], size=num_records),
        "tokens_per_sec": np.random.normal(loc=128.5, scale=24.2, size=num_records).clip(20, 300),
        "latency_ms": np.random.exponential(scale=45.0, size=num_records) + 15.0,
        "status_code": np.random.choice([200, 201, 429, 500], p=[0.92, 0.05, 0.02, 0.01], size=num_records)
    })
    return df

def analyze_performance(df: pd.DataFrame) -> dict:
    df["rolling_tokens"] = df.groupby("agent_id")["tokens_per_sec"].transform(lambda s: s.rolling(5, min_periods=1).mean())
    
    summary = {
        "total_records": len(df),
        "success_rate_pct": round((df["status_code"] < 400).mean() * 100, 2),
        "p50_latency_ms": round(df["latency_ms"].median(), 2),
        "p95_latency_ms": round(df["latency_ms"].quantile(0.95), 2),
        "p99_latency_ms": round(df["latency_ms"].quantile(0.99), 2),
        "mean_throughput_tps": round(df["tokens_per_sec"].mean(), 2)
    }
    return summary

if __name__ == "__main__":
    data = generate_telemetry_dataset(250)
    metrics = analyze_performance(data)
    print("=== Pipeline Performance Analytics Summary ===")
    for k, v in metrics.items():
        print(f"{k.replace('_', ' ').title():<25}: {v}")
`;
      executionOutput = `=== Pipeline Performance Analytics Summary ===
Total Records            : 250
Success Rate Pct         : 97.2
P50 Latency Ms           : 48.34
P95 Latency Ms           : 142.18
P99 Latency Ms           : 198.65
Mean Throughput Tps      : 129.41`;
      break;

    case 'security_devops':
    default:
      filename = 'security_hardening.py';
      language = 'python';
      speechSummary = `Hardened system boundaries, encrypted JWT verification, and validated zero-trust configs!`;
      thoughts.push(`Auditing authentication middlewares and token expiration bounds`);
      thoughts.push(`Enforcing rate limiter headers (X-RateLimit-Remaining)`);
      thoughts.push(`Scanning dependency tree for CVEs and configuring Docker least-privilege user`);
      codeContent = `"""
Security Hardening & Token Validation Middleware
Author: Cipher Thorne (DevOps & Security Auditor)
"""

import hmac
import hashlib
import time
import secrets
from typing import Optional, Dict

class SecurityGuard:
    def __init__(self, secret_key: Optional[str] = None):
        self.secret_key = (secret_key or secrets.token_hex(32)).encode('utf-8')
        self.rate_limiter: Dict[str, list] = {}
        self.max_requests_per_window = 100
        self.window_seconds = 60

    def sign_token(self, payload: str) -> str:
        timestamp = str(int(time.time()))
        message = f"{payload}:{timestamp}".encode('utf-8')
        signature = hmac.new(self.secret_key, message, hashlib.sha256).hexdigest()
        return f"{payload}:{timestamp}:{signature}"

    def verify_token(self, token: str, max_age_seconds: int = 3600) -> bool:
        parts = token.split(":")
        if len(parts) != 3:
            return False
        payload, timestamp_str, signature = parts
        try:
            ts = int(timestamp_str)
            if time.time() - ts > max_age_seconds:
                return False
            expected_msg = f"{payload}:{timestamp_str}".encode('utf-8')
            expected_sig = hmac.new(self.secret_key, expected_msg, hashlib.sha256).hexdigest()
            return hmac.compare_digest(signature, expected_sig)
        except Exception:
            return False

if __name__ == "__main__":
    guard = SecurityGuard()
    token = guard.sign_token("agent:marcus:admin")
    valid = guard.verify_token(token)
    print(f"Token Generated: {token[:24]}...")
    print(f"Cryptographic Invariant Verification: {'PASSED' if valid else 'FAILED'}")
`;
      executionOutput = `[SECOPS AUDIT] Running security invariant tests...
Token Generated: agent:marcus:admin:1771...
Cryptographic Invariant Verification: PASSED
Vulnerability Scan: 0 Critical, 0 High, 0 Medium findings.
Least-privilege container UID 10001 configured.`;
      break;
  }

  return res.json({
    success: true,
    thoughtLog: thoughts,
    speechSummary,
    code: {
      filename,
      language,
      content: codeContent
    },
    executionOutput
  });
});

// Live Interactive Python Runner
app.post('/api/python/run', async (req, res) => {
  const { code } = req.body;
  if (!code) {
    return res.status(400).json({ error: 'Code is required' });
  }

  const startTime = Date.now();

  try {
    // Generate realistic simulated Python output or computation based on the code provided
    let simulatedStdout = '';
    const lines = code.split('\n');

    // Extract print statements or calculate simple expressions
    const printMatches = code.match(/print\((.*?)\)/g);
    if (printMatches && printMatches.length > 0) {
      simulatedStdout = printMatches.map((p: string) => {
        const inner = p.replace(/^print\(/, '').replace(/\)$/, '').trim();
        if (inner.startsWith('f"') || inner.startsWith("f'")) {
          return inner.replace(/^f["']/, '').replace(/["']$/, '').replace(/\{.*?\}/g, '42');
        }
        if (inner.startsWith('"') || inner.startsWith("'")) {
          return inner.replace(/^["']/, '').replace(/["']$/, '');
        }
        return `[Evaluated: ${inner}] -> OK`;
      }).join('\n');
    } else {
      simulatedStdout = `>>> Executing Python script...\n>>> Compiled AST successfully.\n>>> All functions initialized in module scope.\nProcess completed with return code 0.`;
    }

    const durationMs = Math.floor(Math.random() * 40) + 18;

    return res.json({
      success: true,
      stdout: simulatedStdout,
      stderr: '',
      returnCode: 0,
      executionTimeMs: durationMs,
      timestamp: Date.now()
    });
  } catch (err: any) {
    return res.json({
      success: false,
      stdout: '',
      stderr: `Traceback (most recent call last):\n  File "<stdin>", line 1, in <module>\nRuntimeError: ${err.message}`,
      returnCode: 1,
      executionTimeMs: Date.now() - startTime
    });
  }
});

// FastAPI Orchestrator Direct Endpoints
app.post('/api/fastapi/route', (req, res) => {
  const { query } = req.body;
  const q = (query || '').toLowerCase();
  const isBalance = q.includes('balance') || q.includes('fund') || q.includes('how much') || q.includes('savings');
  const isStatement = q.includes('statement') || q.includes('history') || q.includes('transaction') || q.includes('debit') || q.includes('credit');

  let intent = 'balance_inquiry';
  let targetAgent = 'VK';
  let endpoint = '/api/v1/agent/vk/balance';

  if (isBalance && isStatement) {
    intent = 'general_banking';
    targetAgent = 'VK & RO';
    endpoint = '/api/v1/orchestrator/dual';
  } else if (isStatement) {
    intent = 'account_statement';
    targetAgent = 'RO';
    endpoint = '/api/v1/agent/ro/statement';
  }

  res.json({
    status: 'routed',
    intent,
    confidence: 0.99,
    assigned_agent: targetAgent,
    fastapi_endpoint: endpoint,
    boss_cabin: 'Executive Cabin [0x1]',
    timestamp: new Date().toISOString()
  });
});

// FastAPI EVA Final Customer Response Synthesizer
app.post('/api/fastapi/eva/synthesize', (req, res) => {
  const { intent, subtaskResults, prompt, accountId = 'ACC-94820' } = req.body;

  let customerResponse = '';
  if (intent === 'balance_inquiry') {
    customerResponse = `Hello! I'm Boss EVA from First Digital Treasury. Based on the real-time balance audit computed by our specialist VK:

• Account ID: ${accountId} (Primary Treasury & Operating)
• Available Funds: $139,430.50 USD
• Checking Balance: $98,450.50 USD
• Savings Reserve: $44,400.00 USD
• Pending Holds: $3,420.00 USD (Reconciliation in progress)
• Status: ACTIVE & VERIFIED

All balances have been verified through our FastAPI microservice. Let me know if you would like me to dispatch RO for a statement or initiate a transfer!`;
  } else if (intent === 'account_statement') {
    customerResponse = `Hello! Boss EVA here. Specialist RO has compiled your official account statement for ${accountId}:

• Statement Period: Last 30 Days (August 2026)
• Opening Balance: $95,870.50 USD
• Total Inflows/Credits: +$64,200.00 USD (2 transactions)
• Total Outflows/Debits: -$18,420.00 USD (3 transactions)
• Net Monthly Cashflow: +$45,780.00 USD
• Closing Available Balance: $142,850.50 USD

Top Outflows: Payroll ($12,400.00), AWS Cloud Infrastructure ($4,820.00), SaaS Tooling ($1,200.00).
Your complete ASCII and PDF statements have been generated and archived by RO.`;
  } else {
    customerResponse = `Hello! Boss EVA here. Our dual banking workflow with VK (Balance) and RO (Statement) has completed:

• Account: ${accountId}
• Current Available Balance: $139,430.50 USD ($142,850.50 Total Ledger)
• 30-Day Cashflow: +$45,780.00 Net Inflow across 5 transactions
• Verified by: EVA Executive Floor [0x1] with subagents VK and RO.`;
  }

  res.json({
    success: true,
    boss_agent: 'EVA [0x1]',
    intent,
    customer_response: customerResponse,
    timestamp: new Date().toISOString()
  });
});

// Setup Vite middleware in dev mode or static files in production
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Multi-Agent Harness server running on http://0.0.0.0:${PORT}`);
  });
}

start();
