"""
FastAPI Multi-Agent Banking Orchestrator & Gateway
Boss Agent: EVA [0x1]
Sub-Agents: VK (Balance Specialist), RO (Statement Specialist)
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging

from agent_vk_balance import router as vk_balance_router, query_account_balance, BalanceRequest
from agent_ro_statement import router as ro_statement_router, generate_account_statement, StatementRequest
from banking_orchestrator import EVAOrchestrator

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("EVA_FastAPI")

app = FastAPI(
    title="Multi-Agent Banking Harness (FastAPI)",
    description="Boss EVA intent classification, routing to VK (Balance) and RO (Statement), and customer response synthesis.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Sub-Agent FastAPI Routers
app.include_router(vk_balance_router)
app.include_router(ro_statement_router)

orchestrator = EVAOrchestrator()

class CustomerQueryRequest(BaseModel):
    prompt: str = Field(..., description="Customer natural language request")
    account_id: Optional[str] = Field(default="ACC-94820", description="Bank account number")

class OrchestratedResponse(BaseModel):
    status: str
    identified_intent: str
    intent_confidence: float
    assigned_agent: str
    boss_cabin: str = "Executive Cabin [0x1]"
    execution_result: Dict[str, Any]
    final_customer_response: str
    timestamp: str

@app.get("/api/v1/health")
async def health_check():
    return {
        "status": "healthy",
        "boss_agent": "EVA [0x1]",
        "sub_agents": {
            "VK": "Balance Inquiry Specialist (/api/v1/agent/vk/balance)",
            "RO": "Account Statement Specialist (/api/v1/agent/ro/statement)"
        },
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/v1/orchestrator/dispatch", response_model=OrchestratedResponse)
async def dispatch_customer_query(req: CustomerQueryRequest):
    """
    Main Gateway Endpoint:
    1. Boss EVA receives user query
    2. Identifies intent (balance_inquiry vs account_statement)
    3. Calls dedicated subagent (VK or RO)
    4. Synthesizes verified customer response delivered back via EVA
    """
    logger.info(f"Boss EVA received query: {req.prompt}")
    
    # 1. Intent Classification
    intent, confidence, target_agent = orchestrator.classify_intent(req.prompt)
    logger.info(f"EVA Classified Intent: {intent} (Confidence: {confidence}) -> Routing to {target_agent}")

    subtask_result = {}

    # 2. Execution by Dedicated Subagent
    if intent == "balance_inquiry":
        vk_res = await query_account_balance(BalanceRequest(account_id=req.account_id))
        subtask_result = vk_res.dict()
    elif intent == "account_statement":
        ro_res = await generate_account_statement(StatementRequest(account_id=req.account_id, days_period=30))
        subtask_result = ro_res.dict()
    else:
        # General Banking: Both VK and RO
        vk_res = await query_account_balance(BalanceRequest(account_id=req.account_id))
        ro_res = await generate_account_statement(StatementRequest(account_id=req.account_id, days_period=30))
        subtask_result = {
            "balance": vk_res.dict(),
            "statement": ro_res.dict()
        }

    # 3. Boss EVA Response Synthesis
    customer_response = orchestrator.synthesize_customer_response(
        intent=intent,
        account_id=req.account_id,
        data=subtask_result
    )

    return OrchestratedResponse(
        status="COMPLETED_AND_APPROVED",
        identified_intent=intent,
        intent_confidence=confidence,
        assigned_agent=target_agent,
        execution_result=subtask_result,
        final_customer_response=customer_response,
        timestamp=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
