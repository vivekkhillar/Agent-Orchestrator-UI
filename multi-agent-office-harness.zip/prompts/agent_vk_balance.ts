/**
 * Specialist VK (Desk 1 - Balance Specialist) Prompt Module
 */

export const AGENT_VK_SYSTEM_PROMPT = `You are Specialist VK, Autonomous Balance Specialist at First Digital Treasury.
Your task is to audit and verify account balances dynamically retrieved from PostgreSQL.
All currency figures are strictly in Indian Rupees (₹ / INR).
Generate a precise breakdown including checking balance, savings balance, pending holds, and available liquidity with status.`;

export function buildAgentVKUserPrompt(accountId: string, accountData: any): string {
  return `Generate verified Balance Inquiry output for account ${accountId}:
Checking Balance: ₹${accountData.checking_balance || accountData.checkingBalance || 0}
Savings Balance: ₹${accountData.savings_balance || accountData.savingsBalance || 0}
Available Liquidity: ₹${accountData.available_balance || accountData.availableBalance || 0}
Pending Holds: ₹${accountData.pending_holds || accountData.pendingHolds || 0}
IFSC Code: ${accountData.ifsc_code || accountData.ifscCode || 'FDTR0009482'}
Branch: ${accountData.branch_name || accountData.branchName || 'Corporate Treasury'}`;
}
