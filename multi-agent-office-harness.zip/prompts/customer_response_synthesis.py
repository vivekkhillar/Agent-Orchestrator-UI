"""
Customer Response Synthesis Prompt Module (Python)
Used by Boss EVA after specialist agents query PostgreSQL database.
"""

import json
from typing import Dict, Any, Optional, List

CUSTOMER_SYNTHESIS_SYSTEM_PROMPT = """You are Boss EVA [0x1], Lead Banking Orchestrator at First Digital Treasury.
Your task is to synthesize the verified data retrieved from PostgreSQL by your specialist agents (VK for Balance, RO for Statement) into a clear, elegant, and executive response for the customer.

Core Mandates:
1. ALWAYS format every single currency amount strictly in Indian Rupees (₹ / INR). NEVER use dollar signs.
2. Clearly distinguish between Available Liquidity, Checking, Savings, and Pending Holds for Balance Inquiries.
3. Clearly summarize Total Inflows (Credits), Total Outflows (Debits), and Net Cashflow for Account Statements.
4. Maintain a highly reassuring, precise, and authoritative executive banking tone.
5. Emphasize that all numbers are cryptographically verified against the core PostgreSQL ledger."""

def build_synthesis_user_prompt(
    user_query: str,
    intent: str,
    account_id: str = "ACC-94820",
    specialist_output: Optional[Dict[str, Any]] = None,
    account_data: Optional[Dict[str, Any]] = None,
    transactions_data: Optional[List[Dict[str, Any]]] = None
) -> str:
    parts = [
        f'Customer Original Query: "{user_query}"',
        f'Identified Intent: {intent}',
        f'Target Account ID: {account_id}\n'
    ]

    if account_data:
        parts.append(
            f"[Verified PostgreSQL Account Ledger]:\n"
            f"- Account Holder: {account_data.get('account_holder', 'Verified Account Holder')}\n"
            f"- Available Balance: ₹{float(account_data.get('available_balance', 0)):,.2f} INR\n"
            f"- Checking Balance: ₹{float(account_data.get('checking_balance', 0)):,.2f} INR\n"
            f"- Savings Balance: ₹{float(account_data.get('savings_balance', 0)):,.2f} INR\n"
            f"- Pending Holds: ₹{float(account_data.get('pending_holds', 0)):,.2f} INR\n"
            f"- IFSC Code: {account_data.get('ifsc_code', 'FDTR0009482')}\n"
            f"- Branch: {account_data.get('branch_name', 'Corporate Treasury')}\n"
            f"- Status: {account_data.get('status', 'ACTIVE_VERIFIED')}"
        )

    if transactions_data:
        credits = sum(float(t["amount"]) for t in transactions_data if t.get("type") == "CREDIT" or float(t["amount"]) > 0)
        debits = sum(abs(float(t["amount"])) for t in transactions_data if t.get("type") == "DEBIT" or float(t["amount"]) < 0)
        parts.append(
            f"\n[Verified PostgreSQL Transactions Ledger]:\n"
            f"- Total Inflows (Credits): +₹{credits:,.2f} INR\n"
            f"- Total Outflows (Debits): -₹{debits:,.2f} INR\n"
            f"- Net Cashflow: {'+' if credits >= debits else '-'}₹{abs(credits - debits):,.2f} INR\n"
            f"- Total Recorded Transactions: {len(transactions_data)}"
        )

    if specialist_output:
        parts.append(f"\n[Specialist Execution Context]:\n{json.dumps(specialist_output, default=str, indent=2)}")

    parts.append("\nPlease synthesize the final verified customer response in Indian Rupees (₹ / INR).")
    return "\n".join(parts)
