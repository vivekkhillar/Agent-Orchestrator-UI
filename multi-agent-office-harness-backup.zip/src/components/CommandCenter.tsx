import React, { useState, useEffect, useRef } from 'react';
import { TaskAssignment, SubTask, Agent, TelemetryLog, HarnessSettings } from '../types';
import { SubTaskGraph } from './SubTaskGraph';
import { CodeSandbox, CodeFile } from './CodeSandbox';
import { AnalyticsView } from './AnalyticsView';
import { 
  Terminal, 
  GitBranch, 
  Code2, 
  BarChart2, 
  Settings, 
  Send, 
  Sparkles, 
  Play, 
  Pause,
  RefreshCw, 
  Cpu, 
  CheckCircle2, 
  MessageSquare, 
  Zap,
  Mic,
  MicOff,
  Paperclip,
  Activity,
  Layers,
  Flame,
  Snowflake,
  Eye,
  Sliders,
  FileCode
} from 'lucide-react';
import { soundFx } from '../utils/audio';

interface CommandCenterProps {
  currentTask: TaskAssignment | null;
  logs: TelemetryLog[];
  agents: Agent[];
  activeTab: 'dispatch' | 'workflow' | 'code' | 'analytics' | 'settings' | 'monitor' | 'tasks' | 'triggers' | 'memory' | 'workers';
  onChangeTab: (tab: any) => void;
  onDispatchTask: (prompt: string) => void;
  isRunning: boolean;
  codeFiles: CodeFile[];
  activeFileId: string | null;
  onSelectFile: (fileId: string) => void;
  activeSubtaskId: string | null;
  onSelectSubtask: (subtask: SubTask) => void;
  settings: HarnessSettings;
  onUpdateSettings: (newSettings: Partial<HarnessSettings>) => void;
  ollamaStatus: { connected: boolean; message: string };
  hasGeminiKey: boolean;
  onCheckOllama: () => void;
  activeStage?: string | null;
  onFreezeToggle?: () => void;
  isFrozen?: boolean;
}

export const CommandCenter: React.FC<CommandCenterProps> = ({
  currentTask,
  logs,
  agents,
  activeTab,
  onChangeTab,
  onDispatchTask,
  isRunning,
  codeFiles,
  activeFileId,
  onSelectFile,
  activeSubtaskId,
  onSelectSubtask,
  settings,
  onUpdateSettings,
  ollamaStatus,
  hasGeminiKey,
  onCheckOllama,
  activeStage,
  onFreezeToggle,
  isFrozen = false
}) => {
  const [promptInput, setPromptInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const recordingTimerRef = useRef<any>(null);
  const terminalEndRef = useRef<HTMLDivElement | null>(null);

  const bossAgent = agents.find(a => a.isSupervisor) || agents[0];

  // Auto scroll terminal to bottom on new logs
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs, activeStage]);

  // Voice recording simulation
  const handleToggleRecord = () => {
    if (isRecording) {
      // Stop recording and transcribe
      setIsRecording(false);
      clearInterval(recordingTimerRef.current);
      soundFx.playBeep(440, 0.08);
      const voicePrompts = [
        "EVA, check my current available balance and savings reserve for account ACC-94820.",
        "EVA, generate account statement for the past 30 days and export transaction ledger.",
        "EVA, verify multi-currency corporate account ACC-10029 balance across USD and EUR with latest FX rates."
      ];
      const randomPrompt = voicePrompts[Math.floor(Math.random() * voicePrompts.length)];
      setPromptInput(randomPrompt);
      setRecordingSeconds(0);
    } else {
      // Start recording
      setIsRecording(true);
      setRecordingSeconds(0);
      soundFx.playBeep(880, 0.08);
      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds(s => s + 1);
      }, 1000);
    }
  };

  const handleSubmitPrompt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim() || isRunning) return;
    soundFx.playDispatch();
    onDispatchTask(promptInput.trim());
    setPromptInput('');
  };

  const allTabs = [
    { id: 'dispatch', label: '> terminal', icon: Terminal },
    { id: 'monitor', label: '👁 monitor', icon: Eye },
    { id: 'tasks', label: '✓ tasks', icon: CheckCircle2 },
    { id: 'workflow', label: '🕸 graph', icon: GitBranch },
    { id: 'code', label: '💻 sandbox', icon: Code2 },
    { id: 'analytics', label: '📊 activity', icon: BarChart2 },
    { id: 'workers', label: '👥 workers', icon: Sparkles },
    { id: 'settings', label: '⚙ settings', icon: Settings }
  ];

  return (
    <div className="flex flex-col h-full bg-[#131b15] border-l-2 border-[#2b3e30] text-slate-100 overflow-hidden font-mono text-xs shadow-2xl">
      {/* Top Boss Header Card */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#1b261e] border-b-2 border-[#26372b]">
        {/* Boss Profile Badge */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-8 h-8 rounded bg-indigo-600 border border-indigo-400 flex items-center justify-center font-bold text-white shadow-md">
              {bossAgent.name.slice(0, 2).toUpperCase()}
            </div>
            <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#1b261e] animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-xs text-white uppercase tracking-wider">
                {bossAgent.name}
              </span>
              <span className="text-[10px] bg-indigo-900/80 text-indigo-300 px-1 rounded border border-indigo-700/60 font-semibold">
                id: [{bossAgent.codeId}]
              </span>
            </div>
            <div className="text-[10px] text-emerald-400/80">
              Lead Banking Orchestrator &amp; Floor Boss
            </div>
          </div>
        </div>

        {/* Action Toggles: Auto Mode & ICE Freeze */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              soundFx.playBeep(640, 0.03);
              onUpdateSettings({ simulationSpeed: settings.simulationSpeed === 1 ? 2 : 1 });
            }}
            className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 border transition-all ${
              settings.simulationSpeed > 1
                ? 'bg-emerald-600 text-white border-emerald-400'
                : 'bg-[#152019] text-emerald-300 border-[#2e4334] hover:bg-[#1f2e24]'
            }`}
            title="Toggle Fast Auto Mode"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>auto {settings.simulationSpeed}x</span>
          </button>

          <button
            onClick={() => {
              soundFx.playBeep(520, 0.03);
              onFreezeToggle && onFreezeToggle();
            }}
            className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 border transition-all ${
              isFrozen
                ? 'bg-sky-600 text-white border-sky-400'
                : 'bg-[#152019] text-sky-300 border-[#2e4334] hover:bg-[#1f2e24]'
            }`}
            title="Freeze / Pause all office agent movement"
          >
            <Snowflake className="w-3 h-3" />
            <span>{isFrozen ? 'FROZEN' : 'ICE'}</span>
          </button>
        </div>
      </div>

      {/* Tabs Navigation Row */}
      <div className="flex items-center bg-[#162018] border-b border-[#26372b] px-2 py-1 overflow-x-auto gap-1 scrollbar-none">
        {allTabs.map(tab => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                soundFx.playBeep(560, 0.02);
                onChangeTab(tab.id);
              }}
              className={`px-2.5 py-1 rounded text-[10px] whitespace-nowrap transition-all flex items-center gap-1.5 ${
                isActive
                  ? 'bg-[#273b2d] text-emerald-300 font-bold border border-emerald-600/60 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#1c2a20]'
              }`}
            >
              <span>{tab.label}</span>
              {tab.id === 'code' && (
                <span className="bg-[#111913] text-emerald-400 px-1 py-0.2 rounded text-[9px]">
                  {codeFiles.length}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Main Tab Content Viewport */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'dispatch' && (
          <div className="flex flex-col h-full bg-[#0e1610]">
            {/* Terminal Header Info Tag */}
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#141e16] border-b border-[#213023] text-[10px]">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <span className="text-emerald-500 font-mono">#</span>
                <span>fastapi-banking-pipeline</span>
                <span className="text-slate-500">|</span>
                <span className="text-slate-400 font-normal">
                  Boss EVA ↔ Subagent VK/RO Handshake Stream
                </span>
              </div>
              <div className="text-[10px] text-slate-400">
                Model: <span className="text-emerald-300">{settings.defaultEngine === 'gemini' ? 'gemini-3.7-flash' : 'phi3:mini'}</span>
              </div>
            </div>

            {/* Real-Time Live Movement Stage Banner */}
            {activeStage && (
              <div className="bg-[#1c2c20] border-b-2 border-emerald-500/80 px-3 py-2 flex items-center justify-between text-xs animate-pulse">
                <div className="flex items-center gap-2 text-emerald-300 font-bold font-mono">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <span>{activeStage}</span>
                </div>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-700/60">
                  LIVE TRACKING
                </span>
              </div>
            )}

            {/* Live Monospace Terminal Log Viewport */}
            <div className="flex-1 p-3 overflow-auto space-y-2 font-mono text-[11px] leading-relaxed">
              {logs.map((log) => {
                const isOrch = log.type === 'orchestration' || log.type === 'delegation';
                const isCode = log.type === 'code_gen';
                const isErr = log.type === 'error';
                const isThought = log.type === 'thought';

                return (
                  <div
                    key={log.id}
                    className={`p-2 rounded border transition-all ${
                      isOrch
                        ? 'bg-[#18261c] border-emerald-700/70 text-emerald-200'
                        : isCode
                        ? 'bg-[#13232b] border-sky-700/60 text-sky-200'
                        : isErr
                        ? 'bg-rose-950/40 border-rose-800 text-rose-300'
                        : isThought
                        ? 'bg-[#222116] border-amber-800/60 text-amber-200'
                        : 'bg-[#141e17] border-[#253628] text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] mb-1 font-mono text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-100">[{log.agentName}]</span>
                        <span className="text-slate-500">({log.agentRole})</span>
                      </div>
                      <span className="text-[9px] text-slate-500">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="font-mono text-[11px] leading-relaxed break-words whitespace-pre-line">
                      {log.message}
                    </div>
                  </div>
                );
              })}

              {/* Verified Final Customer Response Box */}
              {currentTask?.finalCustomerResponse && !isRunning && (
                <div className="p-3 bg-gradient-to-r from-[#182a1d] to-[#122318] border-2 border-emerald-500/80 rounded-lg shadow-lg">
                  <div className="flex items-center justify-between text-[10px] text-emerald-400 font-bold mb-1.5 pb-1 border-b border-emerald-800">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      OFFICIAL CUSTOMER RESPONSE ROUTED FROM BOSS EVA [0x1]
                    </span>
                    <span className="bg-emerald-900 text-emerald-200 px-1.5 py-0.5 rounded text-[9px]">
                      FASTAPI VERIFIED
                    </span>
                  </div>
                  <div className="text-emerald-100 text-xs leading-relaxed whitespace-pre-line font-mono">
                    {currentTask.finalCustomerResponse}
                  </div>
                </div>
              )}

              {isRunning && (
                <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs py-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Boss EVA and Subagent executing handshake &amp; FastAPI computation...</span>
                </div>
              )}
              <div ref={terminalEndRef} />
            </div>

            {/* Bottom Assignment & Voice Input Area */}
            <form onSubmit={handleSubmitPrompt} className="p-2.5 bg-[#141f17] border-t-2 border-[#26372b] flex flex-col gap-2">
              {/* Voice Record / Live Audio bar */}
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleToggleRecord}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold flex items-center gap-1.5 border transition-all ${
                    isRecording
                      ? 'bg-red-600 text-white border-red-400 animate-pulse'
                      : 'bg-[#1b2a1f] text-slate-300 border-[#2e4334] hover:bg-[#233527]'
                  }`}
                >
                  {isRecording ? (
                    <>
                      <MicOff className="w-3 h-3 text-white" />
                      <span>🔴 recording ({recordingSeconds}s)... click stop to transcribe</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3 h-3 text-red-400" />
                      <span>🔴 record voice task</span>
                    </>
                  )}
                </button>

                <div className="text-[10px] text-slate-400 font-mono">
                  Target: <span className="text-emerald-300 font-bold">Boss EVA [0x1]</span>
                </div>
              </div>

              {/* Message Text Input */}
              <div className="flex gap-2">
                <textarea
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  placeholder="Message EVA... (e.g. Check available balance for ACC-94820, or generate last 30 days statement)"
                  rows={2}
                  disabled={isRunning}
                  className="flex-1 bg-[#0b120d] border border-[#2e4334] focus:border-emerald-500 rounded p-2 text-xs text-slate-200 font-mono resize-none focus:outline-none placeholder:text-slate-600 disabled:opacity-50"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                      handleSubmitPrompt(e);
                    }
                  }}
                />
              </div>

              {/* Action Buttons Row */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      soundFx.playBeep(500, 0.02);
                      setPromptInput(p => p + " [Attach requirements.txt]");
                    }}
                    className="px-2 py-0.8 bg-[#1b2a1f] hover:bg-[#243729] text-slate-300 border border-[#2e4334] rounded text-[10px] flex items-center gap-1"
                  >
                    <Paperclip className="w-2.5 h-2.5" />
                    <span>+ File</span>
                  </button>

                  <span className="text-[10px] bg-[#111a13] text-emerald-400 px-1.5 py-0.5 rounded border border-[#26372b]">
                    [ 0x1 ]
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={!promptInput.trim() || isRunning}
                  className="px-3.5 py-1.2 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-bold text-[11px] flex items-center gap-1.5 transition-all disabled:opacity-40 shadow-md shadow-emerald-700/30"
                >
                  <Send className="w-3 h-3" />
                  <span>Send ↵</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {activeTab === 'monitor' && (
          <div className="p-4 bg-[#0e1610] h-full overflow-auto space-y-3">
            <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Real-time Office Telemetry Monitor
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {agents.map((agent) => (
                <div key={agent.id} className="p-3 bg-[#152019] border border-[#283b2d] rounded-lg">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-slate-200">{agent.name} [{agent.codeId}]</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#1f2f24] text-emerald-300 uppercase">
                      {agent.state.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mb-1">{agent.title}</div>
                  <div className="text-[9px] text-slate-500 font-mono">
                    Coord: ({Math.round(agent.x)}, {Math.round(agent.y)}) → Target: ({Math.round(agent.targetX)}, {Math.round(agent.targetY)})
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'tasks' && (
          <div className="p-4 bg-[#0e1610] h-full overflow-auto space-y-3">
            <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Active Assignment Subtasks ({currentTask?.subtasks?.length || 0})
            </h3>
            {currentTask?.subtasks?.map((st, i) => (
              <div key={st.id} className="p-3 bg-[#152019] border border-[#283b2d] rounded-lg">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-200">#{i + 1} {st.title}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded uppercase font-bold ${
                    st.status === 'completed' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' :
                    st.status === 'in_progress' ? 'bg-sky-950 text-sky-300 border border-sky-700 animate-pulse' :
                    'bg-slate-800 text-slate-400'
                  }`}>
                    {st.status}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 mb-2">{st.description}</div>
                <div className="flex items-center justify-between text-[9px] text-slate-500">
                  <span>Assigned: {agents.find(a => a.id === st.assignedAgentId)?.name || 'Agent'}</span>
                  <span>Progress: {st.progress}%</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'workflow' && (
          <SubTaskGraph
            subtasks={currentTask?.subtasks || []}
            agents={agents}
            activeSubtaskId={activeSubtaskId}
            onSelectSubtask={onSelectSubtask}
          />
        )}

        {activeTab === 'code' && (
          <CodeSandbox
            files={codeFiles}
            activeFileId={activeFileId}
            onSelectFile={onSelectFile}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            agents={agents}
            tasks={currentTask ? [currentTask] : []}
            ollamaStatus={ollamaStatus}
            hasGeminiKey={hasGeminiKey}
          />
        )}

        {activeTab === 'workers' && (
          <div className="p-4 bg-[#0e1610] h-full overflow-auto space-y-3">
            <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Office Worker Hierarchy &amp; Routing
            </h3>
            <div className="space-y-2">
              {agents.map((agent) => (
                <div key={agent.id} className="p-3 bg-[#152019] border border-[#283b2d] rounded-lg flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded flex items-center justify-center font-bold text-white text-xs" style={{ backgroundColor: agent.color }}>
                      {agent.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-bold text-slate-200">{agent.name} [{agent.codeId}]</div>
                      <div className="text-[10px] text-slate-400">{agent.title}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-emerald-300 font-mono">{agent.model}</div>
                    <div className="text-[9px] text-slate-500">Tasks Completed: {agent.stats.tasksCompleted}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="p-4 overflow-auto h-full space-y-4 text-slate-200 bg-[#0e1610]">
            <div>
              <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider mb-1 flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Harness Engine Configuration
              </h3>
              <p className="text-xs text-slate-400 font-sans">
                Configure Ollama Local Docker container and Gemini API backend.
              </p>
            </div>

            {/* Inference Engine Switcher */}
            <div className="p-3 bg-[#152019] border border-[#283b2d] rounded-lg space-y-2.5">
              <label className="text-xs font-bold text-slate-200 flex items-center gap-2">
                <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                Default Inference Engine
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    soundFx.playBeep(600, 0.04);
                    onUpdateSettings({ defaultEngine: 'gemini' });
                  }}
                  className={`p-2.5 rounded border text-left transition-all ${
                    settings.defaultEngine === 'gemini'
                      ? 'bg-emerald-950/80 border-emerald-500 text-white'
                      : 'bg-[#101913] border-[#26372b] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="font-bold text-xs flex items-center gap-1.5 text-emerald-300">
                    <Sparkles className="w-3 h-3" />
                    Google Gemini 3.7 Flash
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1 font-sans">
                    Multi-turn reasoning &amp; code generation
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    soundFx.playBeep(600, 0.04);
                    onUpdateSettings({ defaultEngine: 'ollama' });
                  }}
                  className={`p-2.5 rounded border text-left transition-all ${
                    settings.defaultEngine === 'ollama'
                      ? 'bg-emerald-950/80 border-emerald-500 text-white'
                      : 'bg-[#101913] border-[#26372b] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="font-bold text-xs flex items-center gap-1.5 text-sky-300">
                    <Cpu className="w-3 h-3" />
                    Ollama Local Docker
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1 font-sans">
                    phi3:mini / llama3 on localhost:11434
                  </div>
                </button>
              </div>
            </div>

            {/* Ollama Local Docker Configuration Box */}
            <div className="p-3 bg-[#152019] border border-[#283b2d] rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-200">
                  Ollama Docker Endpoint
                </label>
                <button
                  type="button"
                  onClick={onCheckOllama}
                  className="px-2 py-1 bg-[#1f2f24] hover:bg-[#283c2e] text-emerald-300 border border-emerald-700/60 rounded text-[10px] flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  Test Connection
                </button>
              </div>

              <input
                type="text"
                value={settings.ollamaEndpoint}
                onChange={(e) => onUpdateSettings({ ollamaEndpoint: e.target.value })}
                placeholder="http://localhost:11434"
                className="w-full bg-[#0b120d] border border-[#2e4334] rounded p-2 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
