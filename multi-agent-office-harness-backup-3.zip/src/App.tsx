import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Agent, OfficeRoom, OfficeDesk, TaskAssignment, SubTask, TelemetryLog, HarnessSettings } from './types';
import { INITIAL_AGENTS, INITIAL_ROOMS, INITIAL_DESKS, DEFAULT_SETTINGS, PRESET_ASSIGNMENTS } from './data/initialState';
import { Header } from './components/Header';
import { OfficeCanvas } from './components/OfficeCanvas';
import { CommandCenter } from './components/CommandCenter';
import { AgentRoster } from './components/AgentRoster';
import { AgentInspectorModal } from './components/AgentInspectorModal';
import { CodeFile } from './components/CodeSandbox';
import { soundFx } from './utils/audio';

// Helper to generate realistic paths around walls and through cabin door
function getPathToBossCabin(startX: number, startY: number): { x: number; y: number }[] {
  return [
    { x: startX, y: 235 },      // Walk into bullpen central aisle
    { x: 200, y: 235 },         // Walk along aisle to corridor
    { x: 200, y: 160 },         // Walk through Boss Cabin doorway
    { x: 105, y: 140 }          // Stand in front of Boss executive desk
  ];
}

function getPathToDesk(deskX: number, deskY: number): { x: number; y: number }[] {
  return [
    { x: 105, y: 140 },         // Stand in front of Boss desk
    { x: 200, y: 160 },         // Exit through Boss Cabin doorway
    { x: 200, y: 235 },         // Corridor to bullpen aisle
    { x: deskX, y: 235 },       // Aisle above workstation
    { x: deskX, y: deskY }      // Workstation desk chair
  ];
}

export default function App() {
  const [agents, setAgents] = useState<Agent[]>(INITIAL_AGENTS);
  const [rooms] = useState<OfficeRoom[]>(INITIAL_ROOMS);
  const [desks] = useState<OfficeDesk[]>(INITIAL_DESKS);
  const [settings, setSettings] = useState<HarnessSettings>(DEFAULT_SETTINGS);

  const [currentTask, setCurrentTask] = useState<TaskAssignment | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [isFrozen, setIsFrozen] = useState(false);
  const [activeStage, setActiveStage] = useState<string | null>(null);

  const [logs, setLogs] = useState<TelemetryLog[]>([
    {
      id: 'init_1',
      timestamp: Date.now() - 15000,
      agentId: 'agent_supervisor',
      agentName: 'EVA',
      agentRole: 'supervisor',
      type: 'orchestration',
      message: 'Boss EVA [0x1] ready in Executive Cabin. FastAPI Banking Orchestrator online.'
    },
    {
      id: 'init_2',
      timestamp: Date.now() - 10000,
      agentId: 'agent_vk',
      agentName: 'VK',
      agentRole: 'balance_specialist',
      type: 'orchestration',
      message: 'Specialist VK ready at Desk 1: Dedicated to Balance Inquiry intent.'
    },
    {
      id: 'init_3',
      timestamp: Date.now() - 5000,
      agentId: 'agent_ro',
      agentName: 'RO',
      agentRole: 'statement_specialist',
      type: 'orchestration',
      message: 'Specialist RO ready at Desk 2: Dedicated to Account Statement intent.'
    }
  ]);

  const [codeFiles, setCodeFiles] = useState<CodeFile[]>([
    {
      id: 'file_fastapi',
      filename: 'fastapi_app.py',
      language: 'python',
      content: `"""
FastAPI Multi-Agent Banking Orchestrator & Gateway
Boss Agent: EVA [0x1]
Sub-Agents: VK (Balance Specialist), RO (Statement Specialist)
"""

from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional
from datetime import datetime

from agent_vk_balance import router as vk_balance_router, query_account_balance, BalanceRequest
from agent_ro_statement import router as ro_statement_router, generate_account_statement, StatementRequest
from banking_orchestrator import EVAOrchestrator

app = FastAPI(title="Multi-Agent Banking Harness (FastAPI)")
app.include_router(vk_balance_router)
app.include_router(ro_statement_router)

orchestrator = EVAOrchestrator()

@app.post("/api/v1/orchestrator/dispatch")
async def dispatch_customer_query(prompt: str, account_id: str = "ACC-94820"):
    # 1. Boss EVA classifies intent
    intent, confidence, target_agent = orchestrator.classify_intent(prompt)
    
    # 2. Call dedicated subagent
    if intent == "balance_inquiry":
        res = await query_account_balance(BalanceRequest(account_id=account_id))
    else:
        res = await generate_account_statement(StatementRequest(account_id=account_id, days_period=30))
        
    # 3. Boss EVA synthesizes response back to user
    customer_msg = orchestrator.synthesize_customer_response(intent, account_id, res.dict())
    return {"intent": intent, "assigned_agent": target_agent, "response": customer_msg}
`,
      authorAgentName: 'EVA',
      authorRole: 'supervisor'
    },
    {
      id: 'file_vk',
      filename: 'agent_vk_balance.py',
      language: 'python',
      content: `"""
Agent VK: Dedicated Balance Inquiry Service (FastAPI)
Author: VK (Balance Specialist)
"""

from fastapi import APIRouter
from pydantic import BaseModel, Field
from datetime import datetime

router = APIRouter(prefix="/api/v1/agent/vk", tags=["Balance Inquiry"])

ACCOUNT_DATABASE = {
    "ACC-94820": {
        "account_id": "ACC-94820",
        "account_name": "Primary Treasury & Operating",
        "currency": "USD",
        "checking_balance": 98450.50,
        "savings_balance": 44400.00,
        "pending_holds": 3420.00,
        "status": "ACTIVE_VERIFIED"
    }
}

class BalanceRequest(BaseModel):
    account_id: str = Field(default="ACC-94820")

class BalanceResponse(BaseModel):
    account_id: str
    available_balance: float
    checking_balance: float
    savings_balance: float
    pending_holds: float
    currency: str = "USD"
    processed_by: str = "Agent VK"

@router.post("/balance", response_model=BalanceResponse)
async def query_account_balance(req: BalanceRequest):
    rec = ACCOUNT_DATABASE.get(req.account_id, ACCOUNT_DATABASE["ACC-94820"])
    net = (rec["checking_balance"] + rec["savings_balance"]) - rec["pending_holds"]
    return BalanceResponse(
        account_id=rec["account_id"],
        available_balance=round(net, 2),
        checking_balance=rec["checking_balance"],
        savings_balance=rec["savings_balance"],
        pending_holds=rec["pending_holds"]
    )
`,
      authorAgentName: 'VK',
      authorRole: 'balance_specialist'
    },
    {
      id: 'file_ro',
      filename: 'agent_ro_statement.py',
      language: 'python',
      content: `"""
Agent RO: Dedicated Account Statement Service (FastAPI)
Author: RO (Statement Specialist)
"""

from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import List
from datetime import datetime

router = APIRouter(prefix="/api/v1/agent/ro", tags=["Account Statement"])

MOCK_TRANSACTIONS = [
    {"id": "TXN_1091", "date": "2026-08-22", "description": "STRIPE PAYOUT INFLOW", "amount": 42500.00, "type": "CREDIT"},
    {"id": "TXN_1090", "date": "2026-08-20", "description": "AMAZON WEB SERVICES", "amount": -4820.00, "type": "DEBIT"},
    {"id": "TXN_1089", "date": "2026-08-18", "description": "GUSTO PAYROLL DIRECT", "amount": -12400.00, "type": "DEBIT"}
]

class StatementRequest(BaseModel):
    account_id: str = Field(default="ACC-94820")
    days_period: int = Field(default=30)

class StatementResponse(BaseModel):
    statement_id: str
    account_id: str
    total_credits: float
    total_debits: float
    closing_balance: float = 142850.50
    generated_by: str = "Agent RO"

@router.post("/statement", response_model=StatementResponse)
async def generate_account_statement(req: StatementRequest):
    credits = sum(t["amount"] for t in MOCK_TRANSACTIONS if t["amount"] > 0)
    debits = sum(abs(t["amount"]) for t in MOCK_TRANSACTIONS if t["amount"] < 0)
    return StatementResponse(
        statement_id="STM-20260824-094",
        account_id=req.account_id,
        total_credits=credits,
        total_debits=debits
    )
`,
      authorAgentName: 'RO',
      authorRole: 'statement_specialist'
    }
  ]);
  const [activeFileId, setActiveFileId] = useState<string | null>('file_fastapi');

  const [activeTab, setActiveTab] = useState<'dispatch' | 'workflow' | 'code' | 'analytics' | 'settings' | 'monitor' | 'tasks' | 'triggers' | 'memory' | 'workers'>('dispatch');
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>('agent_supervisor');
  const [inspectorAgent, setInspectorAgent] = useState<Agent | null>(null);
  const [activeSubtaskId, setActiveSubtaskId] = useState<string | null>(null);

  const [hasGeminiKey, setHasGeminiKey] = useState<boolean>(true);
  const [ollamaStatus, setOllamaStatus] = useState<{ connected: boolean; message: string }>({
    connected: false,
    message: 'Local Ollama Docker container not checked yet.'
  });

  // Safe Fetch Helper to prevent unexpected end of JSON input
  const safeJsonPost = async (url: string, body: any, fallback: any = {}) => {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const text = await res.text();
      if (!text || text.trim() === '') {
        return fallback;
      }
      return JSON.parse(text);
    } catch (err: any) {
      console.warn(`[SafeFetch] Error querying ${url}:`, err);
      return fallback;
    }
  };

  // Check health and Ollama status on mount
  const checkHealth = useCallback(async () => {
    try {
      const res = await fetch('/api/health');
      const text = await res.text();
      const data = text ? JSON.parse(text) : {};
      setHasGeminiKey(data.hasGeminiKey !== false);
    } catch {
      setHasGeminiKey(true);
    }
  }, []);

  const checkOllamaStatus = useCallback(async () => {
    try {
      const data = await safeJsonPost('/api/ollama/status', { endpoint: settings.ollamaEndpoint }, {
        connected: false,
        message: 'Could not connect to Ollama.'
      });
      setOllamaStatus({
        connected: !!data.connected,
        message: data.message || 'Ollama connection checked.'
      });
      if (data.connected) {
        soundFx.playBeep(880, 0.08);
      }
    } catch (err: any) {
      setOllamaStatus({
        connected: false,
        message: 'Could not connect to Ollama: ' + err.message
      });
    }
  }, [settings.ollamaEndpoint]);

  useEffect(() => {
    checkHealth();
    checkOllamaStatus();
  }, [checkHealth, checkOllamaStatus]);

  // Main Real-Time Animation & Waypoint Path Interpolation Loop
  useEffect(() => {
    if (isFrozen) return;

    const interval = setInterval(() => {
      setAgents((prevAgents) => {
        return prevAgents.map((agent) => {
          const stepSpeed = 3.5 * settings.simulationSpeed;

          // If agent has active waypoints list
          if (agent.waypoints && agent.waypoints.length > 0) {
            const currentIndex = agent.currentWaypointIndex || 0;
            const currentWaypoint = agent.waypoints[currentIndex];

            if (!currentWaypoint) {
              return { ...agent, waypoints: undefined, currentWaypointIndex: 0 };
            }

            const dx = currentWaypoint.x - agent.x;
            const dy = currentWaypoint.y - agent.y;
            const dist = Math.hypot(dx, dy);

            if (dist > 3.5) {
              const nextX = agent.x + (dx / dist) * Math.min(stepSpeed, dist);
              const nextY = agent.y + (dy / dist) * Math.min(stepSpeed, dist);
              return {
                ...agent,
                x: nextX,
                y: nextY
              };
            } else {
              // Reached current waypoint
              const nextIndex = currentIndex + 1;
              if (nextIndex < agent.waypoints.length) {
                return {
                  ...agent,
                  x: currentWaypoint.x,
                  y: currentWaypoint.y,
                  currentWaypointIndex: nextIndex,
                  targetX: agent.waypoints[agent.waypoints.length - 1].x,
                  targetY: agent.waypoints[agent.waypoints.length - 1].y
                };
              } else {
                // Completed all waypoints to destination!
                const finalPoint = agent.waypoints[agent.waypoints.length - 1];
                return {
                  ...agent,
                  x: finalPoint.x,
                  y: finalPoint.y,
                  targetX: finalPoint.x,
                  targetY: finalPoint.y,
                  waypoints: undefined,
                  currentWaypointIndex: 0
                };
              }
            }
          }

          // Direct linear step if target is different and no waypoints
          const dx = agent.targetX - agent.x;
          const dy = agent.targetY - agent.y;
          const dist = Math.hypot(dx, dy);

          if (dist > 3) {
            const nextX = agent.x + (dx / dist) * Math.min(stepSpeed, dist);
            const nextY = agent.y + (dy / dist) * Math.min(stepSpeed, dist);
            return {
              ...agent,
              x: nextX,
              y: nextY
            };
          } else {
            return {
              ...agent,
              x: agent.targetX,
              y: agent.targetY
            };
          }
        });
      });
    }, 35);

    return () => clearInterval(interval);
  }, [settings.simulationSpeed, isFrozen]);

  // Autonomous Wandering for Idle Agents (Periodic background vitality)
  useEffect(() => {
    if (!settings.autonomousWandering || isRunning || isFrozen) return;

    const wanderInterval = setInterval(() => {
      setAgents((prev) => {
        const idleAgents = prev.filter(a => a.state === 'idle' && !a.activeTaskId && !a.isSupervisor);
        if (idleAgents.length === 0) return prev;

        const luckyAgent = idleAgents[Math.floor(Math.random() * idleAgents.length)];
        const wanderOptions = [
          { x: 800, y: 280, speech: "Grabbing fresh espresso from the cafe bar...", state: 'coffee' as const },
          { x: 420, y: 110, speech: "Checking the whiteboard sprint notes...", state: 'meeting' as const },
          { x: 780, y: 100, speech: "Checking server nodes in lab...", state: 'walking' as const },
          { x: luckyAgent.deskX, y: luckyAgent.deskY, speech: "Back to my desk terminal.", state: 'idle' as const }
        ];

        const chosen = wanderOptions[Math.floor(Math.random() * wanderOptions.length)];

        return prev.map(a => {
          if (a.id === luckyAgent.id) {
            return {
              ...a,
              targetX: chosen.x,
              targetY: chosen.y,
              state: 'walking',
              speechBubble: {
                text: chosen.speech,
                expiresAt: Date.now() + 5000
              }
            };
          }
          return a;
        });
      });
    }, 14000);

    return () => clearInterval(wanderInterval);
  }, [settings.autonomousWandering, isRunning, isFrozen]);

  // Helper to append logs
  const addLog = useCallback((log: Omit<TelemetryLog, 'id' | 'timestamp'>) => {
    setLogs((prev) => [
      ...prev,
      {
        ...log,
        id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        timestamp: Date.now()
      }
    ]);
  }, []);

  // Update specific agent helper
  const updateAgent = useCallback((agentId: string, updates: Partial<Agent>) => {
    setAgents(prev => prev.map(a => a.id === agentId ? { ...a, ...updates } : a));
  }, []);

  // Handle Manual floor click to command an agent to walk
  const handleAgentMove = (agentId: string, targetX: number, targetY: number) => {
    updateAgent(agentId, {
      targetX,
      targetY,
      state: 'walking',
      waypoints: undefined,
      speechBubble: {
        text: `Moving to floor coordinates (${targetX}, ${targetY})`,
        expiresAt: Date.now() + 4000
      }
    });
  };

  // Main "Boss-Sub-Agent" Handshake Real-Time Movement Pipeline
  const handleDispatchTask = async (prompt: string) => {
    setIsRunning(true);
    soundFx.playDispatch();

    // Step 1: Boss EVA in Boss Cabin receives prompt
    updateAgent('agent_supervisor', {
      state: 'idle',
      x: 105,
      y: 85,
      targetX: 105,
      targetY: 85,
      speechBubble: {
        text: "Invoking LLM Intent Classification... Parsing natural language semantics...",
        expiresAt: Date.now() + 8000
      }
    });

    setActiveStage("1/7: BOSS EVA INVOKING LLM INTENT CLASSIFIER IN CABIN [0x1]");

    addLog({
      agentId: 'agent_supervisor',
      agentName: 'EVA',
      agentRole: 'supervisor',
      type: 'orchestration',
      message: `[Boss EVA @ Cabin 0x1] Received task: "${prompt}". Invoking LLM for semantic intent classification.`
    });

    try {
      // Step 2: Orchestrate task into structured subtasks & intent via LLM
      const orchData = await safeJsonPost('/api/agent/orchestrate', {
        prompt,
        model: settings.defaultEngine === 'gemini' ? 'gemini-3.7-flash' : 'ollama:phi3:mini'
      }, {
        intent: prompt.toLowerCase().includes('statement') || prompt.toLowerCase().includes('transaction') ? 'account_statement' : 'balance_inquiry',
        intentConfidence: 0.98,
        plan: `Analyzed customer prompt and routed to dedicated specialist.`
      });

      const identifiedIntent = orchData.intent || 'balance_inquiry';
      const llmReasoning = orchData.llmReasoning || `Intent classified as ${identifiedIntent.toUpperCase()}`;

      addLog({
        agentId: 'agent_supervisor',
        agentName: 'EVA',
        agentRole: 'supervisor',
        type: 'thought',
        message: `[Boss EVA @ Cabin 0x1] LLM Classification Result: [${identifiedIntent.toUpperCase()}] (${((orchData.intentConfidence || 0.98) * 100).toFixed(0)}% confidence). ${llmReasoning}`
      });

      const newSubtasks: SubTask[] = (orchData.subtasks || []).map((st: any, idx: number) => ({
        id: st.id || `subtask_${idx}`,
        parentTaskId: `task_${Date.now()}`,
        title: st.title || `Subtask ${idx + 1}`,
        description: st.description || '',
        assignedAgentId: st.assignedAgentId || (identifiedIntent === 'account_statement' ? 'agent_ro' : 'agent_vk'),
        category: st.category || 'python',
        status: 'queued',
        progress: 0,
        dependencies: st.dependencies || [],
        thoughtLog: []
      }));

      const newTaskAssignment: TaskAssignment = {
        id: `task_${Date.now()}`,
        title: prompt.length > 50 ? prompt.slice(0, 48) + '...' : prompt,
        userPrompt: prompt,
        status: 'in_progress',
        supervisorPlan: orchData.plan,
        subtasks: newSubtasks,
        createdAt: Date.now(),
        totalTokens: 1400,
        totalDurationMs: 0,
        rawRequests: orchData.raw_requests || (orchData.rawRequest ? [orchData.rawRequest] : []),
        rawResponses: orchData.raw_responses || (orchData.rawResponse ? [orchData.rawResponse] : []),
        llmInvocations: orchData.llm_invocations || [],
        usedEngine: orchData.usedEngine || (settings.defaultEngine === 'gemini' ? 'gemini-3.7-flash' : 'phi3:mini'),
        fallbackTriggered: orchData.fallbackTriggered || false
      };

      setCurrentTask(newTaskAssignment);

      // If no subtasks were created (e.g. greeting "hi" or general non-banking query), Boss EVA responds directly without summoning agents
      if (newSubtasks.length === 0) {
        setActiveStage(
          identifiedIntent === 'greeting' 
            ? "BOSS EVA: GREETING & INTENT DISCOVERY (DIRECT)" 
            : "BOSS EVA: AWAITING BANKING INTENT (DIRECT)"
        );

        updateAgent('agent_supervisor', {
          speechBubble: {
            text: identifiedIntent === 'greeting'
              ? "Hello! I am Boss EVA [0x1]. Let me know if you'd like to check your balance or get a statement."
              : "Please specify whether you need a Balance Inquiry or Account Statement.",
            expiresAt: Date.now() + 8000
          }
        });

        addLog({
          agentId: 'agent_supervisor',
          agentName: 'EVA',
          agentRole: 'supervisor',
          type: 'thought',
          message: `[Boss EVA @ Cabin 0x1] LLM determined direct interaction. No subagent movement required for intent: [${identifiedIntent}].`
        });

        await new Promise(r => setTimeout(r, 1200 / settings.simulationSpeed));
      } else {
        // Step 3: Sequential Boss EVA <-> Subagent Movement Handshake Flow (Only when intent is identified)
        for (let i = 0; i < newSubtasks.length; i++) {
          const subtask = newSubtasks[i];
          const assignedAgent = agents.find(a => a.id === subtask.assignedAgentId) || agents[1];

          // --- SUBSTEP A: Boss calls subagent to the cabin ---
        setActiveStage(`STAGE ${i + 1}/${newSubtasks.length}: BOSS EVA SUMMONING ${assignedAgent.name} [INTENT: ${identifiedIntent.toUpperCase()}]`);
        soundFx.playBeep(620, 0.08);

        updateAgent('agent_supervisor', {
          speechBubble: {
            text: `${assignedAgent.name}, report to Executive Cabin for ${identifiedIntent.replace('_', ' ')} task briefing!`,
            expiresAt: Date.now() + 6000
          }
        });

        addLog({
          agentId: 'agent_supervisor',
          agentName: 'EVA',
          agentRole: 'supervisor',
          type: 'delegation',
          message: `[Boss EVA -> ${assignedAgent.name}] Intent classified as [${identifiedIntent}]. Intercom: "${assignedAgent.name}, report to Executive Cabin [0x1] for briefing."`
        });

        await new Promise(r => setTimeout(r, 1200 / settings.simulationSpeed));

        // --- SUBSTEP B: Subagent walks in real-time to Boss Cabin ---
        setActiveStage(`STAGE ${i + 1}/${newSubtasks.length}: ${assignedAgent.name.toUpperCase()} WALKING TO BOSS CABIN`);
        soundFx.playFootstep();

        const pathToCabin = getPathToBossCabin(assignedAgent.x, assignedAgent.y);
        const finalCabinPoint = pathToCabin[pathToCabin.length - 1];

        updateAgent(assignedAgent.id, {
          state: 'walking_to_boss',
          waypoints: pathToCabin,
          currentWaypointIndex: 0,
          targetX: finalCabinPoint.x,
          targetY: finalCabinPoint.y,
          speechBubble: {
            text: "Heading to Boss Cabin for task briefing...",
            expiresAt: Date.now() + 5000
          }
        });

        addLog({
          agentId: assignedAgent.id,
          agentName: assignedAgent.name,
          agentRole: assignedAgent.role,
          type: 'thought',
          message: `[${assignedAgent.name}] Navigating through bullpen aisle -> entering Boss Cabin [0x1].`
        });

        // Wait for subagent to walk to Boss Cabin
        await new Promise(r => setTimeout(r, 2200 / settings.simulationSpeed));

        // Ensure subagent is placed in front of Boss desk
        updateAgent(assignedAgent.id, {
          x: 105,
          y: 140,
          targetX: 105,
          targetY: 140,
          state: 'in_boss_cabin',
          waypoints: undefined,
          speechBubble: {
            text: `I'm here Boss EVA! Ready for ${assignedAgent.role.replace('_', ' ')} assignment.`,
            expiresAt: Date.now() + 5000
          }
        });

        // --- SUBSTEP C: In-Cabin Briefing ---
        setActiveStage(`STAGE ${i + 1}/${newSubtasks.length}: BRIEFING IN CABIN (FASTAPI CONTRACT)`);
        soundFx.playDispatch();

        updateAgent('agent_supervisor', {
          speechBubble: {
            text: `${assignedAgent.name}, here is your assignment: "${subtask.title}". Build and run the FastAPI service.`,
            expiresAt: Date.now() + 6000
          }
        });

        addLog({
          agentId: 'agent_supervisor',
          agentName: 'EVA',
          agentRole: 'supervisor',
          type: 'delegation',
          message: `[Boss EVA -> ${assignedAgent.name} @ Cabin] Handed assignment: "${subtask.title}". FastAPI endpoint schema & account parameters dispatched.`
        });

        await new Promise(r => setTimeout(r, 1800 / settings.simulationSpeed));

        // --- SUBSTEP D: Subagent walks back to workstation desk ---
        setActiveStage(`STAGE ${i + 1}/${newSubtasks.length}: ${assignedAgent.name.toUpperCase()} RETURNING TO WORKSTATION DESK`);
        soundFx.playFootstep();

        const pathToDesk = getPathToDesk(assignedAgent.deskX, assignedAgent.deskY);
        const finalDeskPoint = pathToDesk[pathToDesk.length - 1];

        updateAgent(assignedAgent.id, {
          state: 'walking_to_desk',
          waypoints: pathToDesk,
          currentWaypointIndex: 0,
          targetX: finalDeskPoint.x,
          targetY: finalDeskPoint.y,
          activeTaskId: subtask.id,
          speechBubble: {
            text: "Understood Boss EVA! Returning to desk to build it.",
            expiresAt: Date.now() + 5000
          }
        });

        // Update subtask to in_progress
        setCurrentTask(prev => {
          if (!prev) return null;
          return {
            ...prev,
            subtasks: prev.subtasks.map(s => s.id === subtask.id ? { ...s, status: 'in_progress', progress: 25 } : s)
          };
        });

        addLog({
          agentId: assignedAgent.id,
          agentName: assignedAgent.name,
          agentRole: assignedAgent.role,
          type: 'thought',
          message: `[${assignedAgent.name}] Exiting Boss Cabin -> returning to desk workstation.`
        });

        // Wait for subagent to walk back to desk
        await new Promise(r => setTimeout(r, 2200 / settings.simulationSpeed));

        // --- SUBSTEP E: Coding & Execution at Desk ---
        setActiveStage(`STAGE ${i + 1}/${newSubtasks.length}: ${assignedAgent.name.toUpperCase()} CODING & RUNNING FASTAPI MICROSERVICE`);
        soundFx.playTyping();

        updateAgent(assignedAgent.id, {
          x: assignedAgent.deskX,
          y: assignedAgent.deskY,
          targetX: assignedAgent.deskX,
          targetY: assignedAgent.deskY,
          state: 'coding',
          waypoints: undefined,
          speechBubble: {
            text: "Building FastAPI router, validating schemas, and executing endpoint...",
            expiresAt: Date.now() + 6000
          }
        });

        addLog({
          agentId: assignedAgent.id,
          agentName: assignedAgent.name,
          agentRole: assignedAgent.role,
          type: 'thought',
          message: `[${assignedAgent.name} @ Desk] Executing subtask: "${subtask.title}". Running Python FastAPI service.`
        });

        // Backend execution call
        const execData = await safeJsonPost('/api/agent/execute_subtask', {
          subtask,
          agent: assignedAgent,
          prompt
        }, {
          success: true,
          thoughtLog: ['Executed subtask via resilience handler', 'Reconciled database figures in ₹ (INR)'],
          speechSummary: `${assignedAgent.name} completed ${subtask.title} in Indian Rupees (₹).`,
          code: {
            filename: assignedAgent.id === 'agent_vk' ? 'agent_vk_balance.py' : 'agent_ro_statement.py',
            language: 'python',
            content: `# Validated subtask execution by ${assignedAgent.name}`
          },
          executionOutput: `[POSTGRESQL RESILIENCE] Status: 200 OK | Currency: INR (₹)`
        });

        // Increment stats
        const tokensGenerated = Math.floor(Math.random() * 800) + 450;
        const codeLines = execData.code?.content ? execData.code.content.split('\n').length : 42;

        // Add code artifact to CodeSandbox
        if (execData.code) {
          const newFile: CodeFile = {
            id: `file_${subtask.id}`,
            filename: execData.code.filename,
            language: execData.code.language,
            content: execData.code.content,
            authorAgentName: assignedAgent.name,
            authorRole: assignedAgent.role
          };
          setCodeFiles(prev => [newFile, ...prev.filter(f => f.filename !== newFile.filename)]);
          setActiveFileId(newFile.id);
        }

        // Subtask 100% finished coding
        setCurrentTask(prev => {
          if (!prev) return null;
          const updatedRawReqs = execData?.rawRequest ? [...(prev.rawRequests || []), execData.rawRequest] : prev.rawRequests;
          const updatedRawResps = execData?.rawResponse ? [...(prev.rawResponses || []), execData.rawResponse] : prev.rawResponses;
          return {
            ...prev,
            rawRequests: updatedRawReqs,
            rawResponses: updatedRawResps,
            subtasks: prev.subtasks.map(s => s.id === subtask.id ? {
              ...s,
              status: 'in_progress',
              progress: 90,
              thoughtLog: execData.thoughtLog || [],
              generatedCode: execData.code,
              executionOutput: execData.executionOutput
            } : s)
          };
        });

        await new Promise(r => setTimeout(r, 1600 / settings.simulationSpeed));

        // --- SUBSTEP F: Subagent walks back to Boss Cabin to submit response ---
        setActiveStage(`STAGE ${i + 1}/${newSubtasks.length}: ${assignedAgent.name.toUpperCase()} RETURNING TO BOSS CABIN TO SUBMIT RESPONSE`);
        soundFx.playFootstep();

        const pathToCabinSubmission = getPathToBossCabin(assignedAgent.deskX, assignedAgent.deskY);
        const finalSubmitPoint = pathToCabinSubmission[pathToCabinSubmission.length - 1];

        updateAgent(assignedAgent.id, {
          state: 'walking_to_submit',
          waypoints: pathToCabinSubmission,
          currentWaypointIndex: 0,
          targetX: finalSubmitPoint.x,
          targetY: finalSubmitPoint.y,
          speechBubble: {
            text: "Task completed! Carrying response to Boss Cabin.",
            expiresAt: Date.now() + 5000
          }
        });

        addLog({
          agentId: assignedAgent.id,
          agentName: assignedAgent.name,
          agentRole: assignedAgent.role,
          type: 'code_gen',
          message: `[${assignedAgent.name}] Completed code (${codeLines} LOC). Carrying artifact back to Boss Cabin for review.`
        });

        // Wait for subagent to reach Boss Cabin
        await new Promise(r => setTimeout(r, 2200 / settings.simulationSpeed));

        // --- SUBSTEP G: In-Cabin Submission & Approval ---
        setActiveStage(`STAGE ${i + 1}/${newSubtasks.length}: SUBMISSION & APPROVAL IN BOSS CABIN`);
        soundFx.playTaskComplete();

        updateAgent(assignedAgent.id, {
          x: 105,
          y: 140,
          targetX: 105,
          targetY: 140,
          state: 'submitting',
          waypoints: undefined,
          speechBubble: {
            text: `Boss EVA, here is the verified ${identifiedIntent.replace('_', ' ')} result!`,
            expiresAt: Date.now() + 6000
          },
          stats: {
            tasksCompleted: assignedAgent.stats.tasksCompleted + 1,
            tokensUsed: assignedAgent.stats.tokensUsed + tokensGenerated,
            executionTimeMs: assignedAgent.stats.executionTimeMs + 1800,
            linesOfCode: assignedAgent.stats.linesOfCode + codeLines
          }
        });

        updateAgent('agent_supervisor', {
          speechBubble: {
            text: `Verified ${assignedAgent.name}'s submission! Synthesizing final customer response...`,
            expiresAt: Date.now() + 6000
          }
        });

        // Mark subtask completed
        setCurrentTask(prev => {
          if (!prev) return null;
          return {
            ...prev,
            subtasks: prev.subtasks.map(s => s.id === subtask.id ? { ...s, status: 'completed', progress: 100 } : s)
          };
        });

        addLog({
          agentId: 'agent_supervisor',
          agentName: 'EVA',
          agentRole: 'supervisor',
          type: 'orchestration',
          message: `[Boss EVA @ Cabin 0x1] Approved submission from ${assignedAgent.name}. Subtask "${subtask.title}" verified.`
        });

        await new Promise(r => setTimeout(r, 1800 / settings.simulationSpeed));

        // --- SUBSTEP H: Subagent returns to desk (idle) ---
        const pathToDeskFinal = getPathToDesk(assignedAgent.deskX, assignedAgent.deskY);
        updateAgent(assignedAgent.id, {
          state: 'walking_to_desk',
          waypoints: pathToDeskFinal,
          currentWaypointIndex: 0,
          targetX: assignedAgent.deskX,
          targetY: assignedAgent.deskY,
          activeTaskId: undefined,
          speechBubble: {
            text: "Returning to desk.",
            expiresAt: Date.now() + 4000
          }
        });

        await new Promise(r => setTimeout(r, 1800 / settings.simulationSpeed));

        updateAgent(assignedAgent.id, {
          x: assignedAgent.deskX,
          y: assignedAgent.deskY,
          targetX: assignedAgent.deskX,
          targetY: assignedAgent.deskY,
          state: 'idle',
          waypoints: undefined
        });
      }
    }

      // Step 4: Boss EVA Synthesizes Final Customer Response and Routes it to the User
      setActiveStage("BOSS EVA ROUTING FINAL VERIFIED CUSTOMER RESPONSE");
      soundFx.playSuccess();

      const synthRes = await safeJsonPost('/api/fastapi/eva/synthesize', {
        intent: identifiedIntent,
        prompt,
        accountId: 'ACC-94820'
      }, {
        customer_response: identifiedIntent === 'balance_inquiry'
          ? "Hello! Boss EVA here. Specialist VK has verified your available balance for ACC-94820 in PostgreSQL: ₹1,39,430.50 (₹98,450.50 Checking + ₹44,400.00 Savings - ₹3,420.00 Pending Holds). Status: Active & Verified."
          : "Hello! Boss EVA here. Specialist RO has compiled your 30-day account statement for ACC-94820 in PostgreSQL: +₹64,200.00 Credits, -₹18,420.00 Debits. Net cashflow: +₹45,780.00 INR. Closing balance: ₹1,42,850.50 INR."
      });

      const finalMsg = synthRes?.customer_response || (
        identifiedIntent === 'balance_inquiry'
          ? "Hello! Boss EVA here. Specialist VK has verified your available balance for ACC-94820 in PostgreSQL: ₹1,39,430.50 (₹98,450.50 Checking + ₹44,400.00 Savings - ₹3,420.00 Pending Holds). Status: Active & Verified."
          : "Hello! Boss EVA here. Specialist RO has compiled your 30-day account statement for ACC-94820 in PostgreSQL: +₹64,200.00 Credits, -₹18,420.00 Debits. Net cashflow: +₹45,780.00 INR. Closing balance: ₹1,42,850.50 INR."
      );

      setCurrentTask(prev => {
        if (!prev) return null;
        const updatedRawReqs = synthRes?.rawRequest ? [...(prev.rawRequests || []), synthRes.rawRequest] : prev.rawRequests;
        const updatedRawResps = synthRes?.rawResponse ? [...(prev.rawResponses || []), synthRes.rawResponse] : prev.rawResponses;
        return {
          ...prev,
          rawRequests: updatedRawReqs,
          rawResponses: updatedRawResps,
          status: 'completed',
          completedAt: Date.now(),
          finalCustomerResponse: finalMsg
        };
      });

      updateAgent('agent_supervisor', {
        speechBubble: {
          text: `Task complete! Verified response routed to user: "${finalMsg.slice(0, 75)}..."`,
          expiresAt: Date.now() + 12000
        },
        stats: {
          ...agents[0].stats,
          tasksCompleted: agents[0].stats.tasksCompleted + 1,
          tokensUsed: agents[0].stats.tokensUsed + 1800
        }
      });

      addLog({
        agentId: 'agent_supervisor',
        agentName: 'EVA',
        agentRole: 'supervisor',
        type: 'orchestration',
        message: `[Boss EVA -> Customer Response] ${finalMsg}`
      });

    } catch (err: any) {
      addLog({
        agentId: 'agent_supervisor',
        agentName: 'EVA',
        agentRole: 'supervisor',
        type: 'error',
        message: `Execution issue: ${err.message}. Fallback recovery engaged.`
      });
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0d140e] text-slate-100 overflow-hidden select-none">
      {/* Top Application Header */}
      <Header
        settings={settings}
        onUpdateSettings={(newSettings) => setSettings(prev => ({ ...prev, ...newSettings }))}
        onSelectPreset={(preset) => handleDispatchTask(preset.prompt)}
        isRunning={isRunning}
        activeTaskTitle={currentTask?.title}
        hasGeminiKey={hasGeminiKey}
        ollamaStatus={ollamaStatus}
        onOpenSettings={() => setActiveTab('settings')}
      />

      {/* Main Workspace (Left: 2D Retro Office Canvas, Right: Command Center) */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-0 overflow-hidden">
        {/* Left Column: 2D Office Canvas Floor */}
        <div className="lg:col-span-7 flex flex-col h-full overflow-hidden p-2 bg-[#0a0f0b]">
          <OfficeCanvas
            agents={agents}
            rooms={rooms}
            desks={desks}
            selectedAgentId={selectedAgentId}
            onSelectAgent={(agentId) => setSelectedAgentId(agentId)}
            onAgentMove={handleAgentMove}
            simulationSpeed={settings.simulationSpeed}
            activeMovementStage={activeStage}
          />
        </div>

        {/* Right Column: Command Center & Terminal */}
        <div className="lg:col-span-5 flex flex-col h-full overflow-hidden p-2 pl-0 bg-[#0a0f0b]">
          <CommandCenter
            currentTask={currentTask}
            logs={logs}
            agents={agents}
            activeTab={activeTab}
            onChangeTab={setActiveTab}
            onDispatchTask={handleDispatchTask}
            isRunning={isRunning}
            codeFiles={codeFiles}
            activeFileId={activeFileId}
            onSelectFile={setActiveFileId}
            activeSubtaskId={activeSubtaskId}
            onSelectSubtask={(st) => setActiveSubtaskId(st.id)}
            settings={settings}
            onUpdateSettings={(newSettings) => setSettings(prev => ({ ...prev, ...newSettings }))}
            ollamaStatus={ollamaStatus}
            hasGeminiKey={hasGeminiKey}
            onCheckOllama={checkOllamaStatus}
            activeStage={activeStage}
            isFrozen={isFrozen}
            onFreezeToggle={() => setIsFrozen(f => !f)}
          />
        </div>
      </div>

      {/* Bottom Row: Agent Floor Roster Cards */}
      <AgentRoster
        agents={agents}
        selectedAgentId={selectedAgentId}
        onSelectAgent={(agentId) => {
          setSelectedAgentId(agentId);
          const ag = agents.find(a => a.id === agentId);
          if (ag) setInspectorAgent(ag);
        }}
        onTalkToAgent={(agent) => setInspectorAgent(agent)}
      />

      {/* Agent Inspector Modal */}
      {inspectorAgent && (
        <AgentInspectorModal
          agent={inspectorAgent}
          onClose={() => setInspectorAgent(null)}
          onUpdateAgent={(updates) => {
            updateAgent(inspectorAgent.id, updates);
            setInspectorAgent(prev => prev ? { ...prev, ...updates } : null);
          }}
          onAssignTask={(taskPrompt) => {
            setInspectorAgent(null);
            handleDispatchTask(taskPrompt);
          }}
        />
      )}
    </div>
  );
}
