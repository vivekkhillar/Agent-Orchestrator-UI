import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  X, 
  ArrowRight, 
  CheckCircle2, 
  Layers, 
  Database, 
  Cpu, 
  Bot, 
  ShieldCheck, 
  Activity,
  Terminal,
  Clock,
  Sparkles
} from 'lucide-react';
import { generateArchitecturePdf } from '../utils/generateArchitecturePdf';

interface ArchitectureDocModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureDocModal: React.FC<ArchitectureDocModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'sequence' | 'diagram' | 'api' | 'logger'>('overview');
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handleExportPdf = () => {
    setIsExporting(true);
    try {
      generateArchitecturePdf();
    } catch (e) {
      console.error('Error generating PDF:', e);
    } finally {
      setTimeout(() => setIsExporting(false), 800);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#162019] border border-[#2b3e30] rounded-xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden font-sans text-slate-100">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#111913] border-b border-[#243628] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">
                  System Architecture & Integration Specification
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700/60 font-semibold">
                  v2.0 • Live
                </span>
              </div>
              <p className="text-xs text-slate-400">
                End-to-end query lifecycle, dynamic account ID extraction, function sequence & PDF generator
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExportPdf}
              disabled={isExporting}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold px-4 py-2 rounded-lg shadow-md transition-all cursor-pointer border border-emerald-400/40 disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Generating PDF...' : 'Download PDF Document'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 hover:bg-[#203024] rounded-lg text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 bg-[#131d16] border-b border-[#243628] flex gap-2">
          {[
            { id: 'overview', label: '1. Architecture Overview', icon: Layers },
            { id: 'sequence', label: '2. Function Call Sequence', icon: Clock },
            { id: 'diagram', label: '3. Visual Flow Diagram', icon: Activity },
            { id: 'api', label: '4. API & Data Contracts', icon: Terminal },
            { id: 'logger', label: '5. Step Logger & Auditing', icon: ShieldCheck },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-mono transition-all border-b-2 cursor-pointer ${
                  isActive
                    ? 'text-emerald-300 border-emerald-400 bg-emerald-950/40 font-semibold'
                    : 'text-slate-400 border-transparent hover:text-slate-200 hover:bg-[#18261c]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6 text-sm">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="bg-[#121c15] border border-[#243628] rounded-lg p-5">
                <h3 className="text-emerald-400 font-bold text-sm mb-2 flex items-center gap-2">
                  <Bot className="w-4 h-4" /> Executive Multi-Agent Banking Framework
                </h3>
                <p className="text-slate-300 leading-relaxed text-xs">
                  The Multi-Agent Banking Harness is built on a hierarchical multi-agent state machine. 
                  Incoming queries are received by <strong>Boss EVA (Cabin 0x1)</strong>, who dynamically parses customer account identifiers, performs 2-tier semantic intent classification (Google Gemini 3.7 Flash with fallback to local Ollama phi3:mini), and delegates subtasks to specialized domain agents:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4">
                  <div className="bg-[#18241b] border border-[#2e4233] p-3 rounded-lg">
                    <div className="font-mono text-emerald-400 font-bold text-xs">Boss EVA [Cabin 0x1]</div>
                    <div className="text-[11px] text-slate-300 mt-1">
                      Lead Banking Orchestrator. Dynamic intent classification, zero-DB greetings synthesis, subtask delegation, and verified customer response delivery.
                    </div>
                  </div>
                  <div className="bg-[#18241b] border border-[#2e4233] p-3 rounded-lg">
                    <div className="font-mono text-cyan-400 font-bold text-xs">Specialist VK [Desk 1]</div>
                    <div className="text-[11px] text-slate-300 mt-1">
                      Balance Inquiry Specialist. Queries PostgreSQL <code>accounts</code> table, calculates checking, savings, holds, and verifies available balance in ₹ (INR).
                    </div>
                  </div>
                  <div className="bg-[#18241b] border border-[#2e4233] p-3 rounded-lg">
                    <div className="font-mono text-amber-400 font-bold text-xs">Specialist RO [Desk 2]</div>
                    <div className="text-[11px] text-slate-300 mt-1">
                      Account Statement Specialist. Queries <code>transactions</code> table, computes inflows/outflows, reconciles net cashflow, and formats statement in ₹ (INR).
                    </div>
                  </div>
                </div>
              </div>

              {/* Architectural Principles */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#121c15] border border-[#243628] rounded-lg p-4">
                  <h4 className="text-white font-bold text-xs mb-2 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Dynamic Account Resolution
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Account IDs are extracted strictly from the customer query (e.g. <code>ACC-94820</code> or <code>Account: 12345</code>). If no account ID is provided in the prompt, no hardcoded default is assumed; the system gracefully requests account identification.
                  </p>
                </div>

                <div className="bg-[#121c15] border border-[#243628] rounded-lg p-4">
                  <h4 className="text-white font-bold text-xs mb-2 flex items-center gap-2">
                    <Database className="w-4 h-4 text-cyan-400" /> Zero-DB Greetings Policy
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    General greetings (e.g. "hi", "hello", "good morning") trigger zero database calls. Boss EVA answers immediately from Cabin 0x1, conserving database connections and preventing unnecessary latency.
                  </p>
                </div>

                <div className="bg-[#121c15] border border-[#243628] rounded-lg p-4">
                  <h4 className="text-white font-bold text-xs mb-2 flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-emerald-400" /> Strict 2-Tier Fallback LLM Pipeline
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Tier 1: Google Gemini 3.7 Flash via <code>@google/genai</code>.<br />
                    Tier 2: Local Ollama (<code>phi3:mini</code>) armed as immediate fallback if Gemini is offline or rate-limited.
                  </p>
                </div>

                <div className="bg-[#121c15] border border-[#243628] rounded-lg p-4">
                  <h4 className="text-white font-bold text-xs mb-2 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-amber-400" /> Real-time Step Logger & Audit
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Every step records its status (STARTED, IN_PROGRESS, COMPLETED, VALIDATED, FAILED) with full input parameters, error diagnosis, and raw LLM payload captures for 100% auditability.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SEQUENCE */}
          {activeTab === 'sequence' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-300">
                Detailed function call timeline showing exactly which function is triggered, what data is passed, what actions are executed, and the resulting output at each stage:
              </p>

              {[
                {
                  step: '1',
                  phase: 'Query Ingestion & Account ID Extraction',
                  fn: 'extractAccountIdFromPrompt(prompt) & extractAccountIdFromText()',
                  api: 'Client UI -> Frontend Dispatcher (App.tsx: dispatchTask)',
                  input: 'prompt: "What is my balance for ACC-94820?"',
                  action: 'Runs regex parser matching "ACC-XXXXX" or "account #XXXXX". Sets accountId or leaves as null if absent.',
                  output: 'extractedAccountId = "ACC-94820" | null'
                },
                {
                  step: '2',
                  phase: 'Dynamic Intent Classification & Subtask Generation',
                  fn: 'handleOrchestration() -> invokeLLMTwoTier()',
                  api: 'POST /api/agent/orchestrate & /api/agent/orchestrator/dispatch',
                  input: '{ prompt, accountId?, customInstructions?, model }',
                  action: 'Boss EVA invokes Gemini/Ollama with INTENT_CLASSIFICATION_SYSTEM_PROMPT. Analyzes semantic goal and produces structured subtasks.',
                  output: '{ intent: "balance_inquiry", confidence: 0.98, subtasks: [...], rawRequest, rawResponse }'
                },
                {
                  step: '3',
                  phase: 'Subtask Assignment & Physical Navigation',
                  fn: 'dispatchTask() -> getPathToBossCabin() -> getPathToDesk()',
                  api: 'OfficeCanvas State Machine (React + 60fps Tick)',
                  input: '{ subtasks, assignedAgentId: "agent_vk" }',
                  action: 'If greeting: EVA stays at desk, zero DB. If banking: Specialist agent walks along corridor to Boss Cabin [0x1] to receive assignment, then returns to desk.',
                  output: 'Agent animated walking waypoints, task status set to "in_progress"'
                },
                {
                  step: '4',
                  phase: 'Specialist Subtask Execution & PostgreSQL Ledger Check',
                  fn: 'handleAgentExecute() -> getAccountFromPostgres()',
                  api: 'POST /api/agent/execute_subtask & /api/v1/agent/execute',
                  input: '{ subtask, agent, prompt, accountId }',
                  action: 'Specialist queries PostgreSQL database for real ledger figures, verifies ledger math in ₹ INR, and generates Python microservice + execution output.',
                  output: '{ success: true, speechSummary, thoughtLog, code: { filename, content }, executionOutput }'
                },
                {
                  step: '5',
                  phase: 'Boss EVA Final Customer Response Synthesis',
                  fn: 'app.post("/api/fastapi/eva/synthesize") -> invokeLLMTwoTier()',
                  api: 'POST /api/fastapi/eva/synthesize',
                  input: '{ intent, subtaskResults, prompt, accountId }',
                  action: 'Boss EVA reviews specialist execution output or greeting context. Synthesizes professional, verified customer response in ₹ (INR).',
                  output: '{ success: true, customer_response, usedEngine, fallbackTriggered, rawRequest, rawResponse }'
                },
                {
                  step: '6',
                  phase: 'Step Validation & Audit Logging',
                  fn: 'writeToFileLog() & logAuditToPostgres()',
                  api: 'POST /api/logs/step & PostgreSQL audit_logs table',
                  input: '{ source, level, stepNumber, stepName, status, message, details }',
                  action: 'Persists structured execution step log to server runtime log file and database audit trail with full diagnostics if any step fails.',
                  output: '{ success: true, logged_at: ISO_TIMESTAMP }'
                }
              ].map((item) => (
                <div key={item.step} className="bg-[#121c15] border border-[#243628] rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded bg-emerald-600 text-white font-mono text-xs font-bold flex items-center justify-center">
                        {item.step}
                      </span>
                      <h4 className="text-white font-bold text-xs">{item.phase}</h4>
                    </div>
                    <span className="font-mono text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                      {item.api}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] mt-3 font-mono">
                    <div className="bg-[#18241b] p-2 rounded border border-[#283b2e]">
                      <span className="text-slate-400 font-bold">Function: </span>
                      <span className="text-emerald-300">{item.fn}</span>
                    </div>
                    <div className="bg-[#18241b] p-2 rounded border border-[#283b2e]">
                      <span className="text-slate-400 font-bold">Input: </span>
                      <span className="text-slate-300">{item.input}</span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-300 mt-2 bg-[#141e17] p-2 rounded border border-[#243628]">
                    <strong className="text-slate-200">Actions Performed: </strong>{item.action}
                  </div>

                  <div className="text-[11px] font-mono text-emerald-400 mt-2 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span><strong>Outcome:</strong> {item.output}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: DIAGRAM */}
          {activeTab === 'diagram' && (
            <div className="space-y-4">
              <div className="bg-[#101812] border border-[#243628] rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-emerald-400 font-mono font-bold text-xs flex items-center gap-2">
                    <Activity className="w-4 h-4" /> End-to-End Orchestration Architecture Diagram
                  </h4>
                  <span className="text-[10px] font-mono text-slate-400">ASCII Sequence Chart</span>
                </div>

                <pre className="font-mono text-[10.5px] text-emerald-300 bg-[#0d140e] p-4 rounded-lg overflow-x-auto border border-[#1e2f23] leading-relaxed">
{`   +-----------------------------------------------------------------------------------+
   |                                CUSTOMER CLIENT (UI)                               |
   +-----------------------------------------------------------------------------------+
                                            |
                         1. User Prompt (with Dynamic Account ID)
                                            v
   +-----------------------------------------------------------------------------------+
   |        BOSS EVA [Cabin 0x1] - Intent Classification (POST /api/agent/orchestrate) |
   |        Primary: Google Gemini 3.7 Flash  -->  Fallback: Ollama (phi3:mini)        |
   +-----------------------------------------------------------------------------------+
                         /                          |                          \\
          [Intent: Greetings]           [Intent: Balance Inquiry]     [Intent: Statement]
                 |                                  |                          |
                 v                                  v                          v
       +--------------------+             +--------------------+     +-------------------+
       | ZERO DB ACCESS     |             | SPECIALIST VK      |     | SPECIALIST RO     |
       | Cabin [0x1] Direct |             | Desk 1 (Balance)   |     | Desk 2 (Statement)|
       +--------------------+             +--------------------+     +-------------------+
                 |                                  |                          |
                 |                         SQL: SELECT accounts       SQL: SELECT txns   |
                 |                                  |                          |
                 |                         Reconcile INR (₹)          Reconcile INR (₹)  |
                 \\__________________________________|__________________________/
                                            |
                                            v
   +-----------------------------------------------------------------------------------+
   |       BOSS EVA [0x1] - Final Customer Synthesis (POST /api/fastapi/eva/synthesize)|
   |       Verified monetary presentation in INR (₹) + Raw Request/Response Capture    |
   +-----------------------------------------------------------------------------------+
                                            |
                               6. Verified Response to User
                                            v
   +-----------------------------------------------------------------------------------+
   |      STEP LOGGER (writeToFileLog) + POSTGRESQL AUDIT (logAuditToPostgres)         |
   |      Validates every step status: STARTED -> IN_PROGRESS -> VALIDATED             |
   +-----------------------------------------------------------------------------------+`}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 4: API & CONTRACTS */}
          {activeTab === 'api' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-300">
                Specification of REST endpoints, request payloads, response schemas, and error behavior:
              </p>

              {[
                {
                  method: 'POST',
                  path: '/api/agent/orchestrate',
                  desc: 'Orchestrates customer query, extracts dynamic intent and decomposes into specialist subtasks.',
                  body: `{
  "prompt": "Check balance for ACC-94820",
  "accountId": "ACC-94820", // optional, dynamically extracted
  "model": "gemini-3.7-flash"
}`,
                  resp: `{
  "intent": "balance_inquiry",
  "intentConfidence": 0.98,
  "plan": "Boss EVA routing to Specialist VK",
  "subtasks": [{ "id": "subtask_0", "title": "Check Balance", "assignedAgentId": "agent_vk" }],
  "rawRequest": { "system_prompt": "...", "user_prompt": "..." },
  "rawResponse": { "raw_text": "..." }
}`
                },
                {
                  method: 'POST',
                  path: '/api/agent/execute_subtask',
                  desc: 'Executes subtask by assigned specialist agent with PostgreSQL ledger reconciliation.',
                  body: `{
  "subtask": { "id": "subtask_0", "title": "Check Balance" },
  "agent": { "id": "agent_vk", "name": "VK", "role": "balance_specialist" },
  "prompt": "Check balance for ACC-94820",
  "accountId": "ACC-94820"
}`,
                  resp: `{
  "success": true,
  "speechSummary": "VK verified available balance: ₹1,39,430.50 INR",
  "thoughtLog": ["SELECT * FROM accounts WHERE account_id = 'ACC-94820'"],
  "code": { "filename": "agent_vk_balance.py", "language": "python" },
  "executionOutput": "Available: ₹1,39,430.50 | Checking: ₹98,450.50"
}`
                },
                {
                  method: 'POST',
                  path: '/api/fastapi/eva/synthesize',
                  desc: 'Boss EVA final customer response synthesis with zero-DB for greetings and ledger verification for banking.',
                  body: `{
  "intent": "balance_inquiry",
  "subtaskResults": [...],
  "prompt": "Check balance for ACC-94820",
  "accountId": "ACC-94820"
}`,
                  resp: `{
  "success": true,
  "boss_agent": "EVA [0x1]",
  "customer_response": "Hello! Boss EVA here. Specialist VK has verified available balance for ACC-94820: ₹1,39,430.50 INR.",
  "usedEngine": "gemini-3.7-flash",
  "fallbackTriggered": false
}`
                },
                {
                  method: 'POST',
                  path: '/api/logs/step',
                  desc: 'Logs every executing step into runtime file and PostgreSQL audit table for real-time validation.',
                  body: `{
  "source": "Boss_EVA_[CustomerSynthesis]",
  "level": "STEP_VALIDATION",
  "stepNumber": "SYNTH-BANKING",
  "stepName": "Banking Response Synthesis",
  "status": "VALIDATED",
  "message": "Greetings response delivered successfully. DB calls avoided: TRUE."
}`,
                  resp: `{ "success": true, "logged_at": "2026-08-25T10:15:30.000Z" }`
                }
              ].map((api, idx) => (
                <div key={idx} className="bg-[#121c15] border border-[#243628] rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-sky-600 text-white">
                      {api.method}
                    </span>
                    <span className="font-mono text-xs text-white font-bold">{api.path}</span>
                  </div>
                  <p className="text-xs text-slate-300 mb-3">{api.desc}</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-[10px]">
                    <div>
                      <div className="text-slate-400 mb-1 font-bold">Request Payload:</div>
                      <pre className="bg-[#0d140e] p-2.5 rounded border border-[#1e2f23] text-emerald-300 overflow-x-auto">
                        {api.body}
                      </pre>
                    </div>
                    <div>
                      <div className="text-slate-400 mb-1 font-bold">Response JSON:</div>
                      <pre className="bg-[#0d140e] p-2.5 rounded border border-[#1e2f23] text-cyan-300 overflow-x-auto">
                        {api.resp}
                      </pre>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 5: STEP LOGGER */}
          {activeTab === 'logger' && (
            <div className="space-y-4">
              <div className="bg-[#121c15] border border-[#243628] rounded-lg p-4">
                <h4 className="text-emerald-400 font-bold text-xs mb-2 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" /> Live Step Logger & Validation Diagnostics
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed mb-3">
                  Every execution step writes structured validation logs into both the server-side logger file and PostgreSQL <code>audit_logs</code> table. If any step fails, the exact step number, agent ID, error reason, and validation diagnostics are captured for instant diagnosis.
                </p>

                <div className="space-y-2">
                  {[
                    { step: 'STEP-1', status: 'VALIDATED', name: 'Prompt & Account Validation', msg: 'Prompt validated. Dynamic Account ID extracted: ACC-94820' },
                    { step: 'STEP-2', status: 'VALIDATED', name: '2-Tier Intent Classification', msg: 'Gemini 3.7 classified intent [balance_inquiry] (98% confidence)' },
                    { step: 'STEP-3', status: 'VALIDATED', name: 'Office Desk Routing', msg: 'Subtask dispatched to Specialist VK at Desk 1' },
                    { step: 'STEP-4', status: 'VALIDATED', name: 'PostgreSQL Ledger Query', msg: 'Retrieved accounts row. Available: ₹1,39,430.50 INR' },
                    { step: 'STEP-5', status: 'VALIDATED', name: 'Customer Response Synthesis', msg: 'Boss EVA synthesized final response in ₹ (INR)' }
                  ].map((log, i) => (
                    <div key={i} className="flex items-center justify-between bg-[#18241b] px-3 py-2 rounded border border-[#2e4233] text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] text-emerald-400 font-bold">{log.step}</span>
                        <span className="font-semibold text-white">{log.name}</span>
                        <span className="text-slate-400 text-[11px]">— {log.msg}</span>
                      </div>
                      <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-700 font-bold">
                        {log.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-[#111913] border-t border-[#243628] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Document generated in compliance with Multi-Agent Banking Harness Specification.</span>
          </div>
          <button
            onClick={handleExportPdf}
            className="text-emerald-400 hover:text-emerald-300 font-mono font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Official PDF</span>
          </button>
        </div>

      </div>
    </div>
  );
};
