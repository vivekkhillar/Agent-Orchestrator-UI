import React from 'react';
import { Bot, Volume2, VolumeX, Play, Activity, Cpu, Sparkles, Sliders, Server, Code, FileText, Maximize2, Moon, Sun } from 'lucide-react';
import { HarnessSettings } from '../types';
import { PRESET_ASSIGNMENTS } from '../data/initialState';
import { soundFx } from '../utils/audio';

interface HeaderProps {
  settings: HarnessSettings;
  onUpdateSettings: (newSettings: Partial<HarnessSettings>) => void;
  onSelectPreset: (preset: typeof PRESET_ASSIGNMENTS[0]) => void;
  isRunning: boolean;
  activeTaskTitle?: string;
  hasGeminiKey: boolean;
  ollamaStatus: { connected: boolean; message: string };
  onOpenSettings: () => void;
  onOpenArchitectureDocs?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onUpdateSettings,
  onSelectPreset,
  isRunning,
  activeTaskTitle,
  hasGeminiKey,
  ollamaStatus,
  onOpenSettings,
  onOpenArchitectureDocs
}) => {
  const toggleSound = () => {
    const next = !settings.soundEnabled;
    soundFx.enabled = next;
    onUpdateSettings({ soundEnabled: next });
    if (next) soundFx.playBeep(880, 0.1);
  };

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  return (
    <header className="bg-[#1b261e] border-b-2 border-[#283b2e] px-4 py-2 flex items-center justify-between shadow-lg text-slate-100 flex-wrap gap-2">
      {/* Window Controls & Version Badge */}
      <div className="flex items-center gap-3">
        {/* Retro Traffic Light Buttons */}
        <div className="flex items-center gap-1.5 mr-1">
          <div className="w-3 h-3 rounded-full bg-[#ff5f56] border border-[#e0443e] cursor-pointer hover:opacity-80" />
          <div className="w-3 h-3 rounded-full bg-[#ffbd2e] border border-[#dea123] cursor-pointer hover:opacity-80" />
          <div className="w-3 h-3 rounded-full bg-[#27c93f] border border-[#1aab29] cursor-pointer hover:opacity-80" />
        </div>

        {/* Brand Title */}
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-emerald-600 flex items-center justify-center font-bold text-white text-xs shadow">
            <Bot className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="font-mono text-xs font-bold text-white tracking-wide uppercase">
            Multi-Agent Office Harness
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/90 text-emerald-300 border border-emerald-700/60 font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            v0.0.9 - auto mode on
          </span>
        </div>
      </div>

      {/* Preset Scenario Selector */}
      <div className="flex items-center gap-2">
        <select
          onChange={(e) => {
            const selected = PRESET_ASSIGNMENTS.find(p => p.title === e.target.value);
            if (selected) {
              soundFx.playBeep(440, 0.05);
              onSelectPreset(selected);
            }
          }}
          defaultValue=""
          className="bg-[#141e17] hover:bg-[#19271c] text-emerald-300 text-xs font-mono border border-[#2b3e30] rounded px-2.5 py-1 focus:outline-none focus:border-emerald-500 transition-colors cursor-pointer"
        >
          <option value="" disabled>⚡ Load Preset Scenario...</option>
          {PRESET_ASSIGNMENTS.map((preset, idx) => (
            <option key={idx} value={preset.title}>
              [{preset.category}] {preset.title.slice(0, 42)}...
            </option>
          ))}
        </select>
      </div>

      {/* Engine & Quick Controls */}
      <div className="flex items-center gap-2">
        {/* Architecture & Integration Docs Button */}
        {onOpenArchitectureDocs && (
          <button
            onClick={onOpenArchitectureDocs}
            className="flex items-center gap-1.5 bg-emerald-950/70 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-700/60 rounded px-2.5 py-1 text-xs cursor-pointer transition-all shadow-sm font-mono text-[10px] font-semibold"
            title="Open Architecture & Integration Specification / Download PDF"
          >
            <FileText className="w-3 h-3 text-emerald-400" />
            <span>Architecture & PDF</span>
          </button>
        )}

        {/* Model Provider Pill */}
        <button 
          onClick={onOpenSettings}
          className="flex items-center gap-1.5 bg-[#141e17] hover:bg-[#19271c] border border-[#2b3e30] rounded px-2.5 py-1 text-xs cursor-pointer transition-all text-slate-200"
          title="Configure Engine"
        >
          <Cpu className="w-3 h-3 text-emerald-400" />
          <span className="font-mono text-[10px]">
            Engine: <strong className="text-emerald-300">{settings.defaultEngine === 'gemini' ? 'Gemini 3.7' : 'Ollama phi3'}</strong>
          </span>
          <span className={`w-2 h-2 rounded-full ${hasGeminiKey || ollamaStatus.connected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
        </button>

        {/* Sound Toggle */}
        <button
          onClick={toggleSound}
          className={`p-1.5 rounded border transition-colors ${
            settings.soundEnabled
              ? 'bg-[#18261c] text-emerald-300 border-emerald-700/60'
              : 'bg-[#141e17] text-slate-500 border-[#2b3e30]'
          }`}
          title="Toggle 8-bit Audio SFX"
        >
          {settings.soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
        </button>

        {/* Fullscreen Button */}
        <button
          onClick={handleToggleFullscreen}
          className="p-1.5 bg-[#141e17] hover:bg-[#19271c] text-slate-300 border border-[#2b3e30] rounded transition-colors"
          title="Fullscreen Toggle"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
