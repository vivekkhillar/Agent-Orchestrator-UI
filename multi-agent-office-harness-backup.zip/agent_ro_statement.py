"""
Agent RO: Dedicated Account Statement Module (FastAPI)
Author: RO (Account Statement Specialist)
Endpoint: POST /api/v1/agent/ro/statement
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging

router = APIRouter(prefix="/api/v1/agent/ro", tags=["Account Statement"])
logger = logging.getLogger("AgentRO")

# Easily Configurable Mock Transaction Ledger Database
MOCK_TRANSACTIONS = [
    {
        "id": "TXN_1091", 
        "date": "2026-08-22", 
        "description": "STRIPE PAYOUT INFLOW", 
        "category": "Revenue / Merchant", 
        "amount": 42500.00, 
        "type": "CREDIT", 
        "balance_after": 142850.50
    },
    {
        "id": "TXN_1090", 
        "date": "2026-08-20", 
        "description": "AMAZON WEB SERVICES (AWS)", 
        "category": "Cloud Infrastructure", 
        "amount": -4820.00, 
        "type": "DEBIT", 
        "balance_after": 100350.50
    },
    {
        "id": "TXN_1089", 
        "date": "2026-08-18", 
        "description": "GUSTO PAYROLL DIRECT DEPOSIT", 
        "category": "Payroll & Staff", 
        "amount": -12400.00, 
        "type": "DEBIT", 
        "balance_after": 105170.50
    },
    {
        "id": "TXN_1088", 
        "date": "2026-08-14", 
        "description": "ENTERPRISE CLIENT WIRE", 
        "category": "Revenue / Contracts", 
        "amount": 21700.00, 
        "type": "CREDIT", 
        "balance_after": 117570.50
    },
    {
        "id": "TXN_1087", 
        "date": "2026-08-08", 
        "description": "GITHUB ENTERPRISE & AI API TOOLS", 
        "category": "Software Subscriptions", 
        "amount": -1200.00, 
        "type": "DEBIT", 
        "balance_after": 95870.50
    }
]

class StatementRequest(BaseModel):
    account_id: str = Field(default="ACC-94820", description="Target bank account number")
    days_period: int = Field(default=30, description="Duration of statement in days")
    format_type: str = Field(default="json_and_table", description="Output format: json, ascii, pdf")

class TransactionItem(BaseModel):
    id: str
    date: str
    description: str
    category: str
    amount: float
    type: str
    balance_after: float

class StatementResponse(BaseModel):
    statement_id: str
    account_id: str
    period: str
    opening_balance: float
    closing_balance: float
    total_credits: float
    total_debits: float
    net_change: float
    transaction_count: int
    transactions: List[TransactionItem]
    ascii_table: str
    generated_by: str = "Agent RO (Account Statement Specialist)"

@router.post("/statement", response_model=StatementResponse)
async def generate_account_statement(req: StatementRequest):
    """
    RO's dedicated statement generation endpoint.
    Called by EVA Banking Orchestrator when statement intent is identified.
    """
    logger.info(f"RO Generating statement for {req.account_id} over {req.days_period} days")
    
    total_credits = sum(t["amount"] for t in MOCK_TRANSACTIONS if t["amount"] > 0)
    total_debits = sum(abs(t["amount"]) for t in MOCK_TRANSACTIONS if t["amount"] < 0)
    opening_bal = 95870.50
    closing_bal = 142850.50

    # Build ASCII Statement Table
    table_lines = [
        "=" * 80,
        f"OFFICIAL ACCOUNT STATEMENT | ACCOUNT: {req.account_id} | LAST {req.days_period} DAYS",
        "=" * 80,
        f"{'DATE':<12} {'TXN ID':<10} {'DESCRIPTION':<32} {'TYPE':<8} {'AMOUNT ($)':>12}",
        "-" * 80
    ]
    for t in MOCK_TRANSACTIONS:
        sign = "+" if t["amount"] > 0 else "-"
        table_lines.append(
            f"{t['date']:<12} {t['id']:<10} {t['description']:<32} {t['type']:<8} {sign}${abs(t['amount']):>10,.2f}"
        )
    table_lines.append("-" * 80)
    table_lines.append(f"TOTAL CREDITS : +${total_credits:,.2f}")
    table_lines.append(f"TOTAL DEBITS  : -${total_debits:,.2f}")
    table_lines.append(f"NET CASHFLOW  : +${total_credits - total_debits:,.2f}")
    table_lines.append(f"CLOSING BAL   :  ${closing_bal:,.2f} USD")
    table_lines.append("=" * 80)

    return StatementResponse(
        statement_id=f"STM-{datetime.utcnow().strftime('%Y%m%d')}-094",
        account_id=req.account_id,
        period=f"Last {req.days_period} Days ({datetime.utcnow().strftime('%B %Y')})",
        opening_balance=opening_bal,
        closing_balance=closing_bal,
        total_credits=total_credits,
        total_debits=total_debits,
        net_change=total_credits - total_debits,
        transaction_count=len(MOCK_TRANSACTIONS),
        transactions=[TransactionItem(**t) for t in MOCK_TRANSACTIONS],
        ascii_table="\n".join(table_lines)
    )

if __name__ == "__main__":
    import asyncio
    stmt = asyncio.run(generate_account_statement(StatementRequest(account_id="ACC-94820")))
    print(stmt.ascii_table)
