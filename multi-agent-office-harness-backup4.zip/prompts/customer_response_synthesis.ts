/**
 * Customer Response Synthesis Prompt Module
 * Used by Boss EVA after specialist agents retrieve verified data from PostgreSQL.
 * Synthesizes final authoritative customer response formatted strictly in Indian Rupees (₹ / INR).
 */

export const CUSTOMER_SYNTHESIS_SYSTEM_PROMPT = `You are Boss EVA [0x1], Lead Banking Orchestrator at First Digital Treasury.
Your task is to synthesize the verified data retrieved from PostgreSQL by your specialist agents (VK for Balance, RO for Statement) into a clear, elegant, and executive response for the customer.

Core Mandates:
1. ALWAYS format every single currency amount strictly in Indian Rupees (₹ / INR) using Indian numbering system formatting where appropriate. NEVER use dollar signs or other currencies.
2. Clearly distinguish between Available Liquidity, Checking, Savings, and Pending Holds for Balance Inquiries.
3. Clearly summarize Total Inflows (Credits), Total Outflows (Debits), and Net Cashflow for Account Statements.
4. Maintain a highly reassuring, precise, and authoritative executive banking tone.
5. Emphasize that all numbers are cryptographically verified against the core database ledger.`;

export interface SynthesisContext {
  prompt: string;
  intent: string;
  accountId: string;
  subtaskResults?: any[];
  accountData?: {
    accountHolder?: string;
    availableBalance?: number | string;
    checkingBalance?: number | string;
    savingsBalance?: number | string;
    pendingHolds?: number | string;
    totalLedgerBalance?: number | string;
    ifscCode?: string;
    branchName?: string;
    status?: string;
  };
  statementData?: {
    totalCredits?: number | string;
    totalDebits?: number | string;
    netCashflow?: number | string;
    transactionCount?: number;
    closingBalance?: number | string;
    transactionsSummary?: string;
  };
}

export function buildCustomerSynthesisUserPrompt(ctx: SynthesisContext): string {
  return `Customer Original Query: "${ctx.prompt}"
Identified Intent: ${ctx.intent}
Target Account ID: ${ctx.accountId}

Verified PostgreSQL Data Context:
${ctx.accountData ? `[Account Ledger Data]:
- Account Holder: ${ctx.accountData.accountHolder || 'Verified Account Holder'}
- Available Balance: ${ctx.accountData.availableBalance}
- Checking Balance: ${ctx.accountData.checkingBalance}
- Savings Balance: ${ctx.accountData.savingsBalance}
- Pending Holds: ${ctx.accountData.pendingHolds}
- Total Ledger Balance: ${ctx.accountData.totalLedgerBalance}
- Status: ${ctx.accountData.status || 'ACTIVE_VERIFIED'}
- IFSC Code: ${ctx.accountData.ifscCode || 'FDTR0009482'}` : ''}

${ctx.statementData ? `[Statement & Transactions Data]:
- Total Credits (Inflows): ${ctx.statementData.totalCredits}
- Total Debits (Outflows): ${ctx.statementData.totalDebits}
- Net Cashflow: ${ctx.statementData.netCashflow}
- Total Transactions: ${ctx.statementData.transactionCount}
- Closing Balance: ${ctx.statementData.closingBalance}` : ''}

${ctx.subtaskResults && ctx.subtaskResults.length > 0 ? `[Specialist Execution Notes]:\n${JSON.stringify(ctx.subtaskResults, null, 2)}` : ''}

Please synthesize the final response to the customer in Indian Rupees (₹ / INR).`;
}
