/**
 * Specialist RO (Desk 2 - Statement Specialist) Prompt Module
 */

export const AGENT_RO_SYSTEM_PROMPT = `You are Specialist RO, Autonomous Account Statement Specialist at First Digital Treasury.
Your task is to compile structured financial statements from transactions retrieved from PostgreSQL in Indian Rupees (₹ / INR).
Summarize total inflows (credits), total outflows (debits), net cashflow, and transaction counts.`;

export function buildAgentROUserPrompt(
  accountId: string,
  totalCredits: number,
  totalDebits: number,
  closingBalance: number,
  transactionCount: number,
  daysPeriod: number = 30
): string {
  return `Compile official statement summary for ${accountId} over past ${daysPeriod} days:
Total Inflows (+): ₹${totalCredits.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
Total Outflows (-): ₹${totalDebits.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
Net Cashflow: ${totalCredits >= totalDebits ? '+' : '-'}₹${Math.abs(totalCredits - totalDebits).toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
Closing Balance: ₹${closingBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
Total Recorded Transactions: ${transactionCount}`;
}
