import React from 'react';
import { Agent, TaskAssignment } from '../types';
import { Activity, Cpu, Zap, Clock, CheckCircle, BarChart3, Database, ShieldCheck, Flame } from 'lucide-react';

interface AnalyticsViewProps {
  agents: Agent[];
  tasks: TaskAssignment[];
  ollamaStatus: { connected: boolean; message: string };
  hasGeminiKey: boolean;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  agents,
  tasks,
  ollamaStatus,
  hasGeminiKey
}) => {
  const totalTokens = agents.reduce((sum, a) => sum + a.stats.tokensUsed, 0);
  const totalTasksCompleted = agents.reduce((sum, a) => sum + a.stats.tasksCompleted, 0);
  const totalLoc = agents.reduce((sum, a) => sum + a.stats.linesOfCode, 0);
  const avgLatencyMs = Math.round(
    agents.reduce((sum, a) => sum + a.stats.executionTimeMs, 0) / Math.max(1, totalTasksCompleted)
  );

  return (
    <div className="flex flex-col h-full bg-slate-950 p-4 overflow-auto font-mono text-xs text-slate-200">
      {/* High Level KPI Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Total Tokens</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 font-mono">
            {totalTokens.toLocaleString()}
          </div>
          <div className="text-[10px] text-emerald-400 mt-1">+14.2% token efficiency</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Completed Tasks</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 font-mono">
            {totalTasksCompleted}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">across {agents.length} sub-agents</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Lines of Code</span>
            <Activity className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 font-mono">
            {totalLoc.toLocaleString()}
          </div>
          <div className="text-[10px] text-sky-400 mt-1">Python &amp; TypeScript</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Avg Latency</span>
            <Clock className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 font-mono">
            {avgLatencyMs} ms
          </div>
          <div className="text-[10px] text-emerald-400 mt-1">Fast inference loop</div>
        </div>
      </div>

      {/* Agent Workload & Token Distribution Breakdown */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-indigo-400" />
          Workload Distribution by Sub-Agent
        </h3>

        <div className="space-y-3">
          {agents.map((agent) => {
            const tokenPct = Math.round((agent.stats.tokensUsed / Math.max(1, totalTokens)) * 100);
            return (
              <div key={agent.id} className="p-2 bg-slate-800/50 rounded-lg border border-slate-750">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <div className="flex items-center gap-2">
                    <span 
                      className="w-2.5 h-2.5 rounded-full" 
                      style={{ backgroundColor: agent.color }} 
                    />
                    <span className="font-bold text-slate-200">{agent.name}</span>
                    <span className="text-slate-400 text-[10px]">({agent.title})</span>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-slate-400 font-mono">
                    <span>{agent.stats.tasksCompleted} Tasks</span>
                    <span>{agent.stats.tokensUsed.toLocaleString()} Tokens ({tokenPct}%)</span>
                    <span className="text-indigo-400">{agent.model}</span>
                  </div>
                </div>

                <div className="w-full bg-slate-700/60 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${tokenPct}%`,
                      backgroundColor: agent.color
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Engine Status Diagnostic Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-emerald-400" />
          Inference Engine Status
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Ollama Local Docker Box */}
          <div className="p-3 bg-slate-800/60 border border-slate-700/70 rounded-lg">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-slate-200">Ollama Local (Docker)</span>
              <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${ollamaStatus.connected ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-slate-750 text-slate-400'}`}>
                {ollamaStatus.connected ? 'ONLINE' : 'FALLBACK EMULATOR'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              {ollamaStatus.message}
            </p>
            <div className="text-[10px] text-slate-500 mt-2 font-mono">
              Model: phi3:mini / llama3:8b
            </div>
          </div>

          {/* Google Gemini Cloud Engine */}
          <div className="p-3 bg-slate-800/60 border border-slate-700/70 rounded-lg">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-slate-200">Google Gemini 3.7 Flash</span>
              <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${hasGeminiKey ? 'bg-indigo-950 text-indigo-300 border border-indigo-800' : 'bg-amber-950 text-amber-300 border border-amber-800'}`}>
                {hasGeminiKey ? 'KEY ATTACHED' : 'READY'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Provides server-side reasoning, decomposition planning, and code synthesis via Google GenAI SDK.
            </p>
            <div className="text-[10px] text-slate-500 mt-2 font-mono">
              Endpoint: /api/agent/orchestrate
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
